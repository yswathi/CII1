// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  backendDomain: 'https://192.168.204.13/', // "http://192.168.208.247:8089/" ,
  pythonDomain: 'https://192.168.204.13:3000/', // pythonDomain: 'http://192.168.204.13:3000/',
  knowledgeRepositoryDomain: 'https://192.168.204.13:3001/dev/', // 'http://10.118.45.202:3001/'
  // qaDomain: 'http://192.168.204.73',
  tableauDomain: 'https://192.168.204.232/',
  forecastDomain: 'https://192.168.204.13:8090/',
  botIdleTime: 60000,
  botTimeout: 60000,
  searchItemSeparator: '###',
  searchIncidentSeparator: '##',

  KEYCLOAK_URL: 'https://192.168.204.228:8080/auth',
  KEYCLOAK_REALM: 'ims',
  KEYCLOAK_CLIENTID: 'ims-login',
  KEYCLOAK_CLIENTSECRET: '79ced59f-42f6-462c-bf6d-e24fa8384174'
};
