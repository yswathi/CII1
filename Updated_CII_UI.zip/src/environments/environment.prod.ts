export const environment = {
  production: true,
  backendDomain: './',
  pythonDomain: '/',
  knowledgeRepositoryDomain: './',
  forecastDomain: './',
  botIdleTime: 6000,
  botTimeout: 6000,
  searchItemSeparator: '###',
  searchIncidentSeparator: '##',
  KEYCLOAK_URL: 'http://10.118.45.215:8080/auth',
  KEYCLOAK_REALM: 'master',
  KEYCLOAK_CLIENTID: 'ims-login',
  KEYCLOAK_CLIENTSECRET: '9ee409fa-5434-4d63-8bd0-e8ead5aa7d43',
  tableauDomain: 'http://115.111.91.5/'
};
