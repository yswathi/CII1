import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { environment } from '../environments/environment';

declare var Keycloak: any;

@Injectable()
export class KeycloakService {
    static updateToken: any;
    static auth: any = {};
    static init(): Promise<any> {
        const keycloakAuth: any = Keycloak({
            url: environment.KEYCLOAK_URL,
            realm: environment.KEYCLOAK_REALM,
            clientId: environment.KEYCLOAK_CLIENTID,
            credentials: {
                secret: environment.KEYCLOAK_CLIENTSECRET,
            },
        },
        );

        KeycloakService.auth.loggedIn = false;

        return new Promise((resolve, reject) => {
            keycloakAuth
                .init({ onLoad: 'login-required', checkLoginIframe: false })
                .success(() => {
                    KeycloakService.auth.loggedIn = true;
                    KeycloakService.auth.authz = keycloakAuth;
                    KeycloakService.auth.logoutUrl =
                        keycloakAuth.authServerUrl +
                        '/realms/' +
                        environment.KEYCLOAK_REALM +
                        '/protocol/openid-connect/logout?redirect_uri=' +
                        document.baseURI;
                    KeycloakService.updateToken = keycloakAuth.updateToken;
                    resolve();
                })
                .error(() => {
                    reject();
                });
        });
    }

    getToken() {
        if (KeycloakService.auth.authz.token) {
            return KeycloakService.auth.authz.token;
        }
    }

    refreshToken(): Promise<any> {
        return new Promise((resolve, reject) => {
            if (KeycloakService.auth.authz.token) {
                KeycloakService.auth.authz
                    .updateToken(90) // refresh token if it will expire in 90 seconds or less
                    .success(async () => {
                        resolve(KeycloakService.auth.authz.token);
                    })
                    .error(() => {
                        reject('Failed to refresh token');
                    });
            } else {
                reject('Not logged in');
            }
        });
    }

    logout() {
        KeycloakService.auth.loggedIn = false;
        KeycloakService.auth.authz = null;
        window.location.href = KeycloakService.auth.logoutUrl;
    }
}
