import { AboutCiiComponent } from './components/dashboard/about/about.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { AgGridModule } from 'ag-grid-angular';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonPluginsModule } from './common.module';
import { RoutingModule } from './app.routing.module';
import { ImsWidgetsModule } from './components/ims-widgets/ims-widgets.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from '../shared/token.interceptor';
import { AuthGuard } from './services/authguard.service';
import {MatSliderModule} from '@angular/material/slider';
import { RolesGuard } from './services/roles.guard.service';
import { SpecificRolesGuard } from './services/specificRoles.guard.service';
import {HorizontalBarChartComponent } from './components/dashboard/charts/horizontal-bar-chart.component';
import { DonutChartComponent } from './components/dashboard/donutchart/donut-chart.component';
import { DetailedDashboardComponent } from './components/dashboard/ppmdash/ppmdetaileddashboard/ppmdetailed.component'
import{AccessDeniedComponent} from './components/dashboard/accessDenied/accessDenied.component';
import { EditComponent } from './components/dashboard/ppmdash/ppmdetaileddashboard/edit-ppmdetails/edit.component';
import { ValidComponent } from './components/dashboard/ppmdash/ppmdetaileddashboard/vaildupdate/validupdate.component'
import { Header2Component } from './components/app/header2/header2.component';
import {
  AppComponent,
  HomeComponent,
  TrendForecastComponent,
  SigninComponent,
  DashboardComponent,
  SigninResponseComponent,
  ValueComponent,
  AmsiComponent,
  AutomationComponent,
  MandatoryActionComponent,
  FooterComponent,
  StatisticsComponent,
  AdminComponent,
  AdminServiceComponent,
  KnowledgeServiceComponent,
  KnowledgeCommentsComponent,  
  KnowledgeComponent,
  HeaderComponent,
  DialogComponent,
  BotComponent,
  BodyComponent,
  PromptActionComponent,
  OptionComponent,
  ListComponent,
  ListAllComponent,
  OptionsComponent,
  QuestionsComponent,
  TextComponent,
  BotHeaderComponent,
  BotFooterComponent,
  FeedbackComponent,
  ListToolTipComponent,
  AdminDialogComponent,
  PpmComponent,
  PpmDetailsComponent,
  ValueComponentppm,
} from './components';

import {
  UserService,
  MessageService,
  SocketService,
  AuthenticationService,
  ProxyService,
} from './services';
import { AdmindashComponent } from './components/admindash/admindash.component';
import { KeycloakService } from '../shared/keyCloak.service';
import { TableauService } from '../shared/tableau.service';
import { KnowledgeScoreComponent } from './components/dashboard/knowledge/knowledge-score/knowledge-score.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TrendForecastComponent,
    BotComponent,
    MandatoryActionComponent,
    PromptActionComponent,
    OptionComponent,
    ListComponent,
    ListAllComponent,
    OptionsComponent,
    QuestionsComponent,
    FeedbackComponent,
    TextComponent,
    BotHeaderComponent,
    BodyComponent,
    BotFooterComponent,
    SigninComponent,
    DashboardComponent,
    SigninResponseComponent,
    ValueComponent,
    AmsiComponent,
    AutomationComponent,
    StatisticsComponent,
    AdminComponent,
    AdminServiceComponent,
    KnowledgeComponent,
    HeaderComponent,
    Header2Component,
    FooterComponent,
    DialogComponent,
    ListToolTipComponent,
    AdminDialogComponent,
    PpmComponent,
    PpmDetailsComponent,
    ValueComponentppm,
    AdmindashComponent,
    KnowledgeServiceComponent,
    KnowledgeCommentsComponent,
    AccessDeniedComponent,
    KnowledgeScoreComponent,
    AboutCiiComponent,
    HorizontalBarChartComponent,
    DonutChartComponent,
    DetailedDashboardComponent,
    EditComponent,
    ValidComponent,
    
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule.forRoot(),
    HttpClientModule,
    CommonPluginsModule,
    AgGridModule.withComponents([ListToolTipComponent]),
    NgIdleKeepaliveModule.forRoot(),
    ImsWidgetsModule,
    RoutingModule,
    MatSliderModule
  ],
  providers: [
    UserService,
    MessageService,
    SocketService,
    AuthenticationService,
    ProxyService,
    AuthGuard,
    RolesGuard,
    SpecificRolesGuard,
  //   {  provide: HTTP_INTERCEPTORS,
  //     useClass: TokenInterceptor,
  //     multi: true,
  //  },
   KeycloakService,
   TableauService,
  ],
  entryComponents: [
    DialogComponent,
    AdminServiceComponent,
    AdminDialogComponent,
    ListAllComponent,
    KnowledgeServiceComponent,
    KnowledgeCommentsComponent,
    KnowledgeScoreComponent,
    EditComponent,
    ValidComponent
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
}
