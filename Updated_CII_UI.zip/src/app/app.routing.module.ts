import { DetailedDashboardComponent } from './components/dashboard/ppmdash/ppmdetaileddashboard/ppmdetailed.component';
import { AboutCiiComponent } from './components/dashboard/about/about.component';
import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';

import {
    HomeComponent,
    TrendForecastComponent,
    SigninComponent,
    DashboardComponent,
    SigninResponseComponent,
    ValueComponent,
    AmsiComponent,
    AutomationComponent,
    MandatoryActionComponent,
    StatisticsComponent,
    AdminComponent,
    KnowledgeComponent,
    ValueComponentppm,
} from './components';
import { PpmComponent } from './components/dashboard/ppm/ppm.component';
import { PpmDetailsComponent } from './components/dashboard/ppm/ppmDetails/ppmDetails.component';
import { AdmindashComponent } from './components/admindash/admindash.component';
import{AccessDeniedComponent} from './components/dashboard/accessDenied/accessDenied.component';
import {AuthGuard} from './services/authguard.service';
import {RolesGuard} from './services/roles.guard.service';
import { SpecificRolesGuard } from './services/specificRoles.guard.service';

const routes: Routes = [
   // { path : '', redirectTo:'/signin', pathMatch: 'full'},
    { path: '', redirectTo: '/dashboard/about', pathMatch: 'full' },
    { path: 'signin-response/:otp', component: SigninResponseComponent },
    { path: 'signin', component: SigninComponent },
    { path: 'home', component: HomeComponent },
    { path: 'trend-forecast', component: TrendForecastComponent },
    //{ path: 'admin', component: AdminComponent },
    { path: 'admindashboard', component: AdmindashComponent },
    //{ path: 'notifications', component: PpmComponent },
    
    {
        path: 'dashboard',
        component: DashboardComponent,
        children: [
            // { path: 'automation', component: AutomationComponent, data:{ rowMapper: "TAB1"}, canActivate: [AuthGuard] },
            { path: 'value', component: ValueComponent,  data:{ rowMapper: "TAB2"}, canActivate: [AuthGuard,SpecificRolesGuard] },
            { path: 'amsi', component: AmsiComponent, data:{ rowMapper: "TAB4"}, canActivate: [AuthGuard,SpecificRolesGuard] },
            // { path: 'statistics', component: StatisticsComponent, data:{ rowMapper: "TAB1"}, canActivate: [AuthGuard] },
            //{ path: 'admin', component: AdminComponent },
            { path: 'knowledge', component: KnowledgeComponent, data:{ rowMapper: "TAB1"}, canActivate: [AuthGuard,SpecificRolesGuard, 
            ]},
            { path: 'ppmdash', component: ValueComponentppm,  data:{ rowMapper: "TAB3"}, canActivate: [AuthGuard,SpecificRolesGuard]},
            { path: 'ppmDetails/:id', component: PpmDetailsComponent },
            { path: '', redirectTo: 'about', pathMatch: 'full', canActivate: [
                
            ] },
            { path: 'notifications', component: PpmComponent },
            { path: 'about', component: AboutCiiComponent },
            { path: 'detailedppm', component: DetailedDashboardComponent },
        ]
    },
    {
        path: 'admindashboard',
        component: AdmindashComponent,
        data:{ rowMapper: "TAB5"},
        canActivate: [AuthGuard, SpecificRolesGuard],
        children: [
            { path: '', redirectTo: 'admin', pathMatch: 'full' },
            { path: 'automation', component: AutomationComponent , data:{ rowMapper: "TAB5"}, canActivate: [AuthGuard,SpecificRolesGuard]},
            //{ path: 'value', component: ValueComponent },
            { path: 'statistics', component: StatisticsComponent,  data:{ rowMapper: "TAB5"}, canActivate: [AuthGuard,SpecificRolesGuard] },
            { path: 'admin', component: AdminComponent, data:{ rowMapper: "TAB5"}, canActivate: [AuthGuard,SpecificRolesGuard] },
            //{ path: 'knowledge', component: KnowledgeComponent },
            //{ path: 'ppmdash', component: ValueComponentppm },
            //{path: 'ppmDetails/:id', component: PpmDetailsComponent },
            //{ path: '', redirectTo: 'knowledge', pathMatch: 'full' },
            { path: 'notifications', component: PpmComponent },
        ]
    },
    {path:'AccessDenied',component:AccessDeniedComponent},
];

@NgModule({
    imports: [RouterModule.forRoot(
        routes,
        {useHash: true, enableTracing: false } // <-- debugging purposes only
    )],
    exports: [RouterModule]
})

export class RoutingModule { }
