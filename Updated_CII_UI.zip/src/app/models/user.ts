export interface IUser {
  id?: string;
  name: string;
  avatarUrl?: string;
}

export class User {
  id: string;
  name: string;
  avatarUrl: string;

  constructor(obj?: IUser) {
    this.id = obj && obj.id || null;
    this.name = obj && obj.name || null;
    this.avatarUrl = obj && obj.avatarUrl || null;
  }

}
