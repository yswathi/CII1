export interface frequency {
    frequencyName: string,
    frequencyValue: string
};

export interface mask {
    fieldName: string,
    systemName: string,
    maskEnabled: string,
    customer: string
};

export interface adminItem {
    type: string,
    customer: string;
    automationCronValue: string,
    systemName: string,
    url: string,
    userName: string,
    password: string,
    enableFlag: string,
    fieldsMask: mask[],
    file : File | string,
    frequencyType ?: '',
    frequencyValue? :'',
    email: '',
    id:any,
    fileExists?:boolean,
    description?: string
}
