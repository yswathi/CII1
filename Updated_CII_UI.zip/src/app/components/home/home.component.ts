import { Component } from '@angular/core';
import { SocketService } from '../../services/socket.service';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  public showLoginButton = true;

  constructor(
    private _socketService: SocketService,
    private _authenticationService: AuthenticationService
  ) {
    _socketService.myLogging$.subscribe((newBool: boolean) => {
      this.showLoginButton = !newBool;
    });
  }

  logout() {
    this._authenticationService.idToken = '';
    this.showLoginButton = true;
  }
}
