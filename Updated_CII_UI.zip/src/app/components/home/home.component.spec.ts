import { Component } from '@angular/core';
import { SocketService } from '../../services/socket.service';
import { AuthenticationService } from '../../services/authentication.service';
import { UserService } from '../../services/user.service';
import { MessageService } from '../../services/message.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HomeComponent } from './home.component';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe(' HomeComponent', () => {
  let fixture: ComponentFixture<HomeComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [HomeComponent],
      imports: [HttpClientTestingModule],
      providers: [
        { provide: SocketService, useClass: SocketService },
        { provide: UserService, useClass: UserService },
        { provide: MessageService, useClass: MessageService },
        { provide: AuthenticationService, useClass: AuthenticationService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(HomeComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have logout', async(() => {
    expect(app.logout).toBeDefined();
    app.logout();
  }));
});
