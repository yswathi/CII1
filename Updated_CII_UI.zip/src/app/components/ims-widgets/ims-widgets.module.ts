import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from '../app/loader/loader.component';
import { LoaderService } from '../app/loader/loader.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LoaderComponent],
  exports: [LoaderComponent],
  providers: [LoaderService]
})
export class ImsWidgetsModule { }
