import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminComponent } from './admin.component';
import { DialogComponent } from '../dialog/dialog.component';
import { Component, OnInit } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminServiceComponent } from './service/admin-service.component';
import { HttpClient } from '@angular/common/http';
import { LoaderService } from '../../app/loader/loader.service';
import { MatSnackBarModule, MatMenuModule } from '@angular/material';
import { AdminDialogComponent } from '../adminDialog/dialog.component';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import { isArray } from 'util';
import * as _ from 'underscore';
import { mask } from '../../../models/admin';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe(' AdminComponent', () => {
  const mockDialogRef = {
    close: jasmine.createSpy('close')
  };
  const mockMAT_DIALOG_DATA = {
    close: jasmine.createSpy('close')
  };
  let fixture: ComponentFixture<AdminComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [AdminComponent],
      imports: [
        HttpClientTestingModule,
        ReactiveFormsModule,
        MatSnackBarModule,
        MatDialogModule,
        MatMenuModule,
        FormsModule,
        BrowserAnimationsModule
      ],
      providers: [
        { provide: LoaderService, useClass: LoaderService },
        { provide: ProxyService, useClass: ProxyService },

        {
          provide: MatDialogRef,
          useValue: mockDialogRef
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockMAT_DIALOG_DATA
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AdminComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should define the variables', async(() => {
    expect(app.rowData).toBeDefined();
    expect(app.fcStatus).toBe('OPEN');
    expect(app.krStatus).toBe('OPEN');
    expect(app.intervalTime).toEqual(100);
    expect(app.masksList).toBeDefined();
  }));
  it('should  have getServices()', async(() => {
    expect(app.getServices).toBeDefined();
    app.getServices();
  }));
  it('should  have loadServices()', async(() => {
    expect(app.loadServices).toBeDefined();
    app.loadServices();
  }));
  it('should  have agInit()', async(() => {
    expect(app.agInit).toBeDefined();
    app.agInit();
  }));
  it('should  have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should  have  setStep()', async(() => {
    expect(app.setStep).toBeDefined();
    app.setStep();
  }));
  it('should  have  rowTriggered', async(() => {
    expect(app.rowTriggered).toBeDefined();
    var e = {
      event: {
        target: {
          getAttribute: 'start'
        }
      },
      data: 'any'
    };
    app.rowTriggered(e);
  }));
  it('should  have  rowTriggered', async(() => {
    expect(app.rowTriggered).toBeDefined();
    var e = {
      event: {},
      data: 'any'
    };
    app.rowTriggered(e);
  }));
  it('should  have cellTriggered()', async(() => {
    expect(app.cellTriggered).toBeDefined();
    app.e = {
      data: {
        event: {
          target: 'start'
        },
        data: 'any',
        actionType: 'start'
      }
    };
    app.cellTriggered();
  }));
  it('should  have startStopServer()', async(() => {
    expect(app.startStopServer).toBeDefined();
    app.startStopServer();
  }));
  it('should  have getMasks()', async(() => {
    expect(app.getMasks).toBeDefined();
    app.getMasks();
  }));
  it('should  have openDialog()', async(() => {
    expect(app.openDialog).toBeDefined();
    app.openDialog();
  }));
  it('should  have buildFc()', async(() => {
    expect(app.buildFc).toBeDefined();
    app.buildFc();
  }));
  it('should  have updateFrequency()', async(() => {
    expect(app.updateFrequency).toBeDefined();
    app.updateFrequency();
  }));
  it('should  have deleteServer()', async(() => {
    expect(app.deleteServer).toBeDefined();
    app.deleteServer();
  }));
  it('should  have  getDescription()', async(() => {
    expect(app.getDescription).toBeDefined();
    app.getDescription();
  }));
  it('should  have  getDescription()', async(() => {
    expect(app.getDescription).toBeDefined();
    var frequency = {
      frequencyType: 'Minutes'
    };
    app.getDescription(frequency);
  }));
  it('should  have  getDescription()', async(() => {
    expect(app.getDescription).toBeDefined();
    var frequency = {
      frequencyType: 'Hourly'
    };
    app.getDescription(frequency);
  }));
  it('should  have  getDescription()', async(() => {
    expect(app.getDescription).toBeDefined();
    var frequency = {
      frequencyType: 'Daily'
    };
    app.getDescription(frequency);
  }));
  it('should  have  getDescription()', async(() => {
    expect(app.getDescription).toBeDefined();
    var frequency = {
      frequencyType: 'Weekly'
    };
    app.getDescription(frequency);
  }));

  it('should  have  getDescription()', async(() => {
    expect(app.getDescription).toBeDefined();
    var frequency = {
      frequencyType: 'test'
    };
    app.getDescription(frequency);
  }));
});

/* it('should have selected', () => {
  var option = {
    id: 0
  };
  var option2 = {
    id: 1
  };
  expect(app.selected).toBeDefined();
  app.selected(option);
  app.selected(option2);
}); */
