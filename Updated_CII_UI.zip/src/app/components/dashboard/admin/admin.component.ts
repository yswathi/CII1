import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AdminServiceComponent } from './service/admin-service.component';
import { HttpClient } from '@angular/common/http';
import { LoaderService } from '../../app/loader/loader.service';
import { MatSnackBar } from '@angular/material';
import { AdminDialogComponent } from '../adminDialog/dialog.component';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import { UserService } from '../../../services/user.service';
import { isArray } from 'util';
import { DatePipe } from '@angular/common';
import * as _ from 'underscore';
import { mask } from '../../../models/admin';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  private snackBar: MatSnackBar;
  public userid: string;
  public password: string;
  public params: any;
  private http: HttpClient;
  private dialog: MatDialog;
  private loader: LoaderService;
  inProgress: boolean;
  rowData: any;
  modelInterval: any;
  fcStatus: any = 'OPEN';
  krStatus: any = 'OPEN';
  ppmStatus: any = 'OPEN';
  krmStatus: any = 'OPEN';
  fcmStatus: any = 'OPEN';
  nextLoadStatus: any = ' OPEN';
  tableauRefreshStatus: any = 'OPEN';
  trStatus: any = 'OPEN';
  masksList: mask[] = [];
  intervalTime: number = 100;
  selectedCustomer: string = '';
  selectedService: string = '';
  frequencyDetails: any = {};
  customerData: any = {};
  allVersions: object = {};
  selectedVersion: string | number;
  isVersionNeeded: boolean = false;
  versionsList: Array<string> = [];
  customerGroup: Array<string> = [];
  isFTP: boolean = true;
  krDate: any;
  fcDate: any; ppmDate: any; krmDate: any; fcmDate: any; nextLoadTime: any; trDate: any; tableauRefreshDate: any;
  customers: any[] = [];
  //customers = [{ value: 'Deloitte', viewValue: 'Deloitte' }];
  ciiservcies = [{ value: 'Knowledge Repository Model', minMax: false, key: '', url: 'ims/externalService/buildKRModel/' },
  { value: 'Forecast Model', minMax: false, key: '', url: 'ims/externalService/buildForecastModel/' },
  { value: 'Predict Knowledge Repository', minMax: true, key: 'KR', url: 'ims/externalService/predictKRAndPPM/KR/' },
  { value: 'Forecast', minMax: false, key: '', url: 'ims/externalService/forecasting/' },
  { value: 'Generate PPM', minMax: true, key: 'PPM', url: 'ims/externalService/predictKRAndPPM/PPM/' },
  { value: 'Tableau Refresh', minMax: false, key: '', url: 'ims/externalService/refreshTableauAPI/' }];
  weekData = {
    SUN: 'Sunday',
    MON: 'Monday',
    TUE: 'Tuesday',
    WED: 'Wednesday',
    THU: 'Thursday',
    FRI: 'Friday',
    SAT: 'Saturday',
  };

  columnDefs = [];
  constructor(
    httpClient: HttpClient,
    matDialog: MatDialog,
    loaderService: LoaderService,
    private api: ProxyService,
    snack: MatSnackBar,
    private datePipe: DatePipe,
    private userService: UserService,
  ) {
    this.http = httpClient;
    this.dialog = matDialog;
    this.inProgress = false;
    this.loader = loaderService;
    this.rowData = [];
    this.snackBar = snack;
    this.userService.getSelectedCustomer().subscribe((data) => {
      // console.log(data);
      this.selectedCustomer = data;
    });
  }

  getColumnDefs() {
    return [
      {
        headerName: 'Ticketing Tool',
        field: 'systemName',
        width: 150,
        cellRenderer: params => {
          return `<a href="javascript:void(0)" class='a_grid'>${
            params.value
            }</a>`;
        }
      },
      { headerName: 'Type', field: 'type', width: 150 },
      /*{
        headerName: 'Frequency',
        field: 'automationCronValue',
        width: 150,
        cellRenderer: params => {
          return this.getDescription(params.data);
        }
      },*/
      {
        headerName: 'Scheduler',
        field: 'enableFlag',
        width: 150,
        autoHeight: true,
        hide: this.getFTPStatus(),
        cellRenderer: function (params) {
          if (params.value === 'Y') {
            return `
                  <i class="fa fa-play curser-not-allowed" style="color:green;font-size:20px;padding-top:5px" disabled></i>
                  <i class="fa fa-stop cursor-pointer" style="color:red;font-size:20px;padding-top:5px;margin-left:10px;" data-action-type="stop" title="OFF"></i>`;
          } else {
            return `<i class="fa fa-play cursor-pointer" style="color:green;font-size:20px;padding-top:5px;" data-action-type="start" title="ON"></i>
                   <i class="fa fa-stop curser-not-allowed" style="color:red;font-size:20px;padding-top:5px;margin-left:10px;" disabled></i>`;
          }
        }
      },
      {
        headerName: 'Actions',
        field: 'actions',
        autoHeight: true,
        template: `
              <i class="fa fa-pencil cursor-pointer grid-icon"  data-action-type="edit" title="Edit" style="color: black;"></i>
              <i class="fa fa-trash-o cursor-pointer grid-icon" style="margin-left:10px; color: black;" data-action-type="remove" title="Delete"></i>`
      },
      {
        headerName: 'Description',
        field: 'description',
        autoHeight: true,
      },
    ];
  }

  getFTPStatus() {
    return this.isFTP;
  }
  getServices() {
    this.loader.start();
    this.rowData = [];
    return this.http.get(environment.backendDomain + 'ims/ticketsystem/service/' + this.selectedCustomer, {});
  }
  loadServices(flag:boolean): void {
    if(flag==true){
    this.snackBar.open('Refreshing Services !', null, {
      duration: 2000,
    });
  }
    this.getServices().subscribe(
      (data: any) => {
        const response = data;
        if (response.statusCode === "1001") {
          const data = _.groupBy(response.data, 'customer');
          for (const key in data) {
            if (data.hasOwnProperty(key)) {
              this.rowData.push({
                customerName: key,
                customerSystems: data[key],
              });
            }
          }
          // console.log(this.rowData, 'rowData');
          const customerSystemData = this.rowData[0].customerSystems[0];
          this.isFTP = customerSystemData.type == 'FTP';
          this.columnDefs = this.getColumnDefs();
          this.loader.stop();
        } else if (response.statusCode === '1114') {
          this.rowData = [];
          this.loader.stop();
        } else {
          this.snackBar.open('Fetching Services Failed !', 'Operation', {
            duration: 10000,
          });
          this.loader.stop();
        }
      },
      () => {
        this.snackBar.open('Fetching Services Failed !', 'Operation', {
          duration: 10000,
        });
        this.rowData = [];
        this.loader.stop();
      },
    );
  }
  agInit(params: any): void {
    this.params = params;
  }

  fnChangeService() {
    let selectedServiceObj = this.ciiservcies.filter(item => item.value.includes(this.selectedService));
    if (selectedServiceObj[0].minMax) {
      this.versionsList = this.allVersions[selectedServiceObj[0]['key']];
      this.isVersionNeeded = true;
      this.selectedVersion = "";
    } else {
      this.isVersionNeeded = false;
      this.selectedVersion = "1";
    }
  }

  fetchVersion() {
    this.http.get(environment.backendDomain + 'ims/externalService/failedVersions/' + this.selectedCustomer, {})
      .subscribe((data: any) => {
        const response = data;
        if (response.statusCode === "1001") {
          this.allVersions = response.data;
        }
      });
  }

  getCustomerGroup() {
    this.api
      .get(`${environment.backendDomain}ims/ticketsystem/customers`, true)
      .subscribe((data: any) => {
        const response = JSON.parse(data);
        if (response) {
          this.customerGroup = response;
        }
      });
  }

  ngOnInit(): void {
    this.getCustomerGroup();
    this.getCustomersDetails();    
    this.getFrequencyData();
  }

  getCustomersDetails(){
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 0) {
        this.customers = res;
        
        if (this.selectedCustomer == null || this.selectedCustomer === undefined) {
          this.selectedCustomer = this.customers[0];
        }
        // this.customers = this.customers.concat(res);
        // this.selectedCustomer = this.customers[0];
        this.userService.setSelectedCustomer(this.selectedCustomer);
        this.customerData = { 'customer': this.selectedCustomer };
        this.loadAllSectionsData();
        this.fetchVersion();
        console.log(this.customerData)

      } else {
        this.customers = res;
      }
    }, error => {
    });
  }

  loadAllSectionsData() {
    this.updateInterval();
    this.getMasks();
    this.loadServices(true);
    this.getFrequencyData();
  }

  rowTriggered(e) {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute('data-action-type');
      console.log(actionType);
      switch (actionType) {
        case 'start':
          return this.startStopServer(e, actionType);
        case 'stop':
          return this.startStopServer(e, actionType);
        case 'edit':
          return this.openDialog(data);
        case 'remove':
          return this.deleteServer(data);
      }
    }
  }

  cellTriggered(event) {
    if (event.colDef.headerName === 'Ticketing Tool') {
     
      this.openDialog(event.data, true);
    }
  }

  deleteServer(data: any) {
    console.log('delete ${data.id}', data);
    const dialogRef = this.dialog.open(AdminDialogComponent, {
      width: '400px',
      hasBackdrop: true,
      disableClose: true,
      data: {
        type: 'delete',
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {

        this.api
          .delete(`${environment.backendDomain}ims/ticketsystem/${data.id}`)
          .subscribe((res) => {
            this.snackBar.open(result.message, null, {
              duration: 3000
            });
            this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
              if (res.length > 0) {
                this.customers = res;
                this.customerChange(res[0]);
              } else {
                this.customers = res;
                this.customerChange('');
              }
            }, error => {
            });
            this.getCustomerGroup();
            //  this.loadServices();
            // this.rowData = [];
          });
      }

    });


  }

  startStopServer(event: any, action) {
    console.log('start action clicked  ', event.data);
    let id = action === 'start' ? 'resume' : 'pause';
    const value = (id === 'resume') ? 'Y' : 'N';
    this.api
      // .patch(
      //   `${environment.backendDomain}ims/job/groups/${
      //   event.data.customer
      //   }/jobs/${event.data.systemName}/${id}`
      // )
      .get(
        `${environment.backendDomain}ims/ticketsystem/pauseOrResumeJob/${event.data.customer}/${value}`
      )
      .subscribe(res => {
        if (action === 'start') {
          event.source.rowNode.setDataValue('enableFlag', 'Y');
        } else {
          event.source.rowNode.setDataValue('enableFlag', 'N');
        }
      });
  }

  getMasks() {
    this.api
      .get(`${environment.backendDomain}ims/ticketsystem/loadmaskingfields`)
      .subscribe(res => {
        this.masksList = res;
      });
  }

  openDialog(data?, flag?) {

    if (data) {
      if (data.url == undefined || data.url == "null") {
        data.url = ''
      }
      if (data.userName == undefined || data.userName == "null") {
        data.userName = ''
      }
      if (data.password == undefined || data.password == "null") {
        data.password = ''
      }
    }
    const dialogRef = this.dialog.open(AdminServiceComponent, {
      width: '800px',
      height: '600px',
      hasBackdrop: true,
      disableClose: true,
      data: {
        serviceData: data ? data : { 'customer': '' },
        isEdit: data ? true : false,
        masksList: this.masksList,
        isView: flag,
        customerGroup: this.customerGroup,
        customer: this.selectedCustomer,
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result && result.message) {
        if (result.statusCode === '1001') {
          let snackBarResp = this.snackBar.open(result.message, null, {
            duration: 3000
          });
          this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
            if (res.length > 0) {
              this.customers = res;
              this.customerChange(res[0]);
            } else {
              this.customers = res;
            }
          }, error => {
          });
          this.getCustomerGroup();
          snackBarResp.afterDismissed().subscribe(() => {
           
          });
        } else {

          let snackBarResp = this.snackBar.open(result.message, null, {
            duration: 3000
          });
         // this.getCustomerGroup();
          // this.getCustomersDetails();   
          // this.getFrequencyData();
          snackBarResp.afterDismissed().subscribe(() => {
         
          });
        }
      }
    });
    this.getMasks();
    this.loadServices(false);
  }

  updateInterval() {
    // this.modelInterval = setTimeout(() => {
    //   this.api
    //     .get(`${environment.backendDomain}ims/statistics/statusReport/${this.seleditedCustomer}`, true)
    //     .subscribe((data: any) => {
    //       const response = JSON.parse(data);
    //       if (response.statusCode === "1001") {
    //         this.krStatus = response.data.krStatus;
    //         this.krDate = this.datePipe.transform(response.data.krStatusDate, 'MM-dd-yyyy HH:mm:ss');
    //         this.fcStatus = response.data.forecastStatus;
    //         this.fcDate = this.datePipe.transform(response.data.forecastStatusDate, 'MM-dd-yyyy HH:mm:ss');
    //         this.ppmStatus = response.data.ppmStatus;
    //         this.ppmDate = this.datePipe.transform(response.data.ppmStatusDate, 'MM-dd-yyyy HH:mm:ss');
    //         this.krmStatus = response.data.krModelStatus;
    //         this.krmDate = this.datePipe.transform(response.data.krModelStatusDate, 'MM-dd-yyyy HH:mm:ss');
    //         this.fcmStatus = response.data.forecastModelStatus;
    //         this.fcmDate = this.datePipe.transform(response.data.forecastModelStatusDate, 'MM-dd-yyyy HH:mm:ss');
    //       }
    //     });
    //   this.api
    //     .get(`${environment.backendDomain}ims/ticketsystem/service/${this.selectedCustomer}`, true)
    //     .subscribe((data: any) => {
    //       const response = JSON.parse(data);
    //       if (response.statusCode === "1001") {
    //         console.log("next exec time");
    //         this.nextLoadTime = this.datePipe.transform(response.data[0].nextExecutionTime, 'MM-dd-yyyy HH:mm:ss');
    //         console.log(this.nextLoadTime);
    //       }
    //     });
    /*this.api
      .get(`${environment.backendDomain}ims/configuration/getKrStatus`, true)
      .subscribe((res: string) => {
        this.krStatus = res;
      });

    this.api
      .get(
        `${environment.backendDomain}ims/configuration/getForecastStatus`,
        true
      )
      .subscribe(res => {
        this.fcStatus = res;
      });

    this.api
      .get(`${environment.backendDomain}ims/configuration/getPpmStatus`, true)
      .subscribe(res => {
        this.ppmStatus = res;
      });*/

    //
    this.getStatusReport();
    this.getTicketSystem();
  }
  getStatusReport() {
    this.api
      .get(`${environment.backendDomain}ims/statistics/statusReport/${this.selectedCustomer}`, true)
      .subscribe((data: any) => {
        const response = JSON.parse(data);
        if (response.statusCode === "1001") {
          this.krStatus = response.data.krStatus;
          console.log(this.krStatus);

          this.krDate = this.datePipe.transform(response.data.krStatusDate, 'MM-dd-yyyy HH:mm:ss');

          this.fcStatus = response.data.forecastStatus;
          this.fcDate = this.datePipe.transform(response.data.forecastStatusDate, 'MM-dd-yyyy HH:mm:ss');

          this.ppmStatus = response.data.ppmStatus;
          this.ppmDate = this.datePipe.transform(response.data.ppmStatusDate, 'MM-dd-yyyy HH:mm:ss');

          this.krmStatus = response.data.krModelStatus;
          this.krmDate = this.datePipe.transform(response.data.krModelStatusDate, 'MM-dd-yyyy HH:mm:ss');

          this.fcmStatus = response.data.forecastModelStatus;
          this.fcmDate = this.datePipe.transform(response.data.forecastModelStatusDate, 'MM-dd-yyyy HH:mm:ss');

          this.tableauRefreshStatus = response.data.tableauStatus;
          this.tableauRefreshDate = this.datePipe.transform(response.data.tableauStatusDate, 'MM-dd-yyyy HH:mm:ss');

        } else {
          this.krStatus = 'OPEN';
          this.krDate = '';
          this.fcStatus = 'OPEN';
          this.fcDate = '';
          this.ppmStatus = 'OPEN';
          this.ppmDate = '';
          this.krmStatus = 'OPEN';
          this.krmDate = '';
          this.fcmStatus = 'OPEN';
          this.fcmDate = '';
          this.tableauRefreshStatus = 'OPEN';
          this.tableauRefreshDate = '';
        }
      });
  }
  getTicketSystem() {
    this.api
      .get(`${environment.backendDomain}ims/ticketsystem/service/${this.selectedCustomer}`, true)
      .subscribe((data: any) => {
        let response = JSON.parse(data);
        if (response.statusCode === "1001") {
          //console.log("next exec time");
          this.nextLoadTime = this.datePipe.transform(response.data[0].nextExecutionTime, 'MM-dd-yyyy HH:mm:ss');
          //  console.log(this.nextLoadTime);
        } else {
          this.nextLoadTime = '';
        }
      });

  }

  updateFrequency(type) {
    let freq: any = {};
    if (type === 'kr') {
      freq.frequencyName = this.frequencyDetails.krType
        ? this.frequencyDetails.krType
        : '';
      freq.frequencyValue = this.frequencyDetails.krValue
        ? this.frequencyDetails.krValue
        : '';
    } else if (type === 'api') {
      freq.frequencyName = this.frequencyDetails.apiType
        ? this.frequencyDetails.apiType
        : '';
      freq.frequencyValue = this.frequencyDetails.apiValue
        ? this.frequencyDetails.apiValue
        : '';
    } else {
      freq.frequencyName = this.frequencyDetails.fcType
        ? this.frequencyDetails.fcType
        : '';
      freq.frequencyValue = this.frequencyDetails.fcValue
        ? this.frequencyDetails.fcValue
        : '';
    }
    const dialogRef = this.dialog.open(AdminDialogComponent, {
      width: '600px',
      hasBackdrop: true,
      disableClose: true,
      data: {
        type: 'frequency',
        frequency: freq,
        isApi: type === 'api' ? true : false
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let payload: any = {
          property: type,
          value: result.cornValue,
          frequencyValue: result.frequencyValue,
          frequencyType: result.frequencyType
        };
        this.api
          .post(
            `${environment.backendDomain}ims/configuration/updateCron`,
            payload
          )
          .subscribe(res => {
            // console.log(res);
            this.getFrequencyData();
          });
      }
    });
  }

  customerChange(value) {
    this.selectedCustomer = value;
    this.userService.setSelectedCustomer(this.selectedCustomer);
    this.loadAllSectionsData();
    this.fetchVersion();
  }

  getFrequencyData() {
    this.api
      .get(`${environment.backendDomain}ims/configuration/cron`)
      .subscribe(res => {
        // console.log(res);
        _.forEach(res, (value: any) => {
          if (value.property === 'kr.cronvalue') {
            this.frequencyDetails.krType = value.frequencyType;
            this.frequencyDetails.krValue = value.frequencyValue;
            this.frequencyDetails.krDesc = this.getDescription(value);
          }
          if (value.property === 'forecast.cronvalue') {
            this.frequencyDetails.fcType = value.frequencyType;
            this.frequencyDetails.fcValue = value.frequencyValue;
            this.frequencyDetails.fcDesc = this.getDescription(value);
          }

          if (value.property === 'api.cronvalue') {
            this.frequencyDetails.apiType = value.frequencyType;
            this.frequencyDetails.apiValue = value.frequencyValue;
            this.frequencyDetails.apiDesc = this.getDescription(value);
          }
        });
      });
  }

  getDescription(frequency) {
    let expresion = '';
    if (frequency.frequencyType === 'Minutes') {
      expresion = `Every ${frequency.frequencyValue} Minute(s)`;
    } else if (frequency.frequencyType === 'Hourly') {
      expresion = `Every ${frequency.frequencyValue} Hour(s)`;
    } else if (frequency.frequencyType === 'Daily') {
      expresion = `Every ${frequency.frequencyValue} Day(s)`;
    } else if (frequency.frequencyType === 'Weekly') {
      expresion = `Every` + ' ' + this.weekData[frequency.frequencyValue];
    } else {
      expresion = `Every ${frequency.frequencyValue} Month(s)`;
    }
    return expresion;
  }

  buildService() {
    let selectedServiceObj = this.ciiservcies.filter(item => item.value.includes(this.selectedService));
    if (!selectedServiceObj[0].minMax) {
      this.api.get(`${environment.forecastDomain}${selectedServiceObj[0].url}${this.selectedCustomer}`).subscribe((res) => {
        this.snackBar.open(res.message, null, {
          duration: 1000,
        });
        if (res.statusCode === '1001') {
          this.getStatusReport();
        }
      });
    } else {
      this.api.get(`${environment.forecastDomain}${selectedServiceObj[0].url}${this.selectedCustomer}/${this.selectedVersion}`)
        .subscribe((res) => {
          this.snackBar.open(res.message, null, {
            duration: 1000,
          });
          if (res.statusCode === '1001') {
            this.getStatusReport();
          }
        }, (error) => {
          this.snackBar.open(error.error.text, null, { duration: 1000 });
        });
    }

  }

  ngOnDestroy() {
    clearTimeout(this.modelInterval);
  }
}
