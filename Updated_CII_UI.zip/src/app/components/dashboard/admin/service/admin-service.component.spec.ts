import { Component, OnInit, Inject } from '@angular/core';
import { DialogComponent } from '../../dialog/dialog.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { adminItem, mask } from '../../../../models/admin';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import * as _ from 'underscore';
import { AdminServiceComponent } from './admin-service.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
describe('AdminServiceComponent', () => {
  let fixture: ComponentFixture<AdminServiceComponent>;
  let app: any;
  const mockDialogRef = {
    close: jasmine.createSpy('close')
  };
  const mockMAT_DIALOG_DATA = {
    close: jasmine.createSpy('close')
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [AdminServiceComponent],
      imports: [
        HttpClientTestingModule,
        ReactiveFormsModule,
        NgbModule.forRoot()
      ],
      providers: [
        { provide: ProxyService, useClass: ProxyService },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockMAT_DIALOG_DATA
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AdminServiceComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should  have  addUpdateServer()', async(() => {
    expect(app.addUpdateServer).toBeDefined();
    app.data = {
      isEdit: 'test'
    };
    app.addUpdateServer();
  }));
  it('should  have  addUpdateServer()', async(() => {
    expect(app.addUpdateServer).toBeDefined();
    app.data = {
      
    };
    app.addUpdateServer();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Minutes'
    };
    app.createCronExpression();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Hourly'
    };
    app.createCronExpression();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Daily'
    };
    app.createCronExpression();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Weekly'
    };
    app.createCronExpression();
  }));
  it('should  have  updateExpression()', async(() => {
    expect(app.updateExpression).toBeDefined();
    app.serveiceItem = {
      automationCronValue: '0 1 2 12'
    };
    app.updateExpression();
  }));
  it('should  have  updateExpression()', async(() => {
    expect(app.updateExpression).toBeDefined();
    app.serveiceItem = {
      type: '',
      customer: '',
      automationCronValue: '0 0 2 12',
      systemName: '',
      url: '',
      userName: '',
      password: '',
      enableFlag: 'Y',
      fieldsMask: []
    };
    app.updateExpression();
  }));
  it('should  have  updateExpression()', async(() => {
    expect(app.updateExpression).toBeDefined();
    app.serveiceItem = {
      type: '',
      customer: '',
      automationCronValue: '0 0 0 12 *',
      systemName: '',
      url: '',
      userName: '',
      password: '',
      enableFlag: 'Y',
      fieldsMask: []
    };
    app.updateExpression();
  }));
  it('should  have  updateExpression()', async(() => {
    expect(app.updateExpression).toBeDefined();
    app.serveiceItem = {
      type: '',
      customer: '',
      automationCronValue: '0 0 0 0 * 0 0',
      systemName: '',
      url: '',
      userName: '',
      password: '',
      enableFlag: 'Y',
      fieldsMask: []
    };
    app.updateExpression();
  }));
  it('should  have  updateExpression()', async(() => {
    expect(app.updateExpression).toBeDefined();
    app.serveiceItem = {
      type: '',
      customer: '',
      automationCronValue: '0 0 0 0 * * 0',
      systemName: '',
      url: '',
      userName: '',
      password: '',
      enableFlag: 'Y',
      fieldsMask: []
    };
    app.updateExpression();
  }));
  it('should  have closeDialog()', async(() => {
    expect(app.closeDialog).toBeDefined();
    app.closeDialog();
  }));
  it('should  have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
});
