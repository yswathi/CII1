import { Component, OnDestroy } from '@angular/core';

import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-list-tooltip',
  templateUrl: './list-tooltip.component.html'
})
export class ListToolTipComponent
  implements ICellRendererAngularComp, OnDestroy {
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }
  ngOnDestroy() {
    console.log('Destroying ListToolTipComponent');
  }

  refresh(): boolean {
    return false;
  }
}
