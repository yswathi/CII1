import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment'
import * as _ from 'underscore';

@Component({
  selector: 'admin-modal-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class AdminDialogComponent implements OnInit {
  frequencyForm: FormGroup;
  cornValue: any;

  frequency: any = {
    frequencyName: '', frequencyValue: ''
  };

  frequencies = [
    { value: 'Minutes', viewValue: 'Minutes' },
    { value: 'Hourly', viewValue: 'Hourly' },
    { value: 'Daily', viewValue: 'Daily' },
    { value: 'Weekly', viewValue: 'Weekly' },
    { value: 'Monthly', viewValue: 'Monthly' }
  ];

  frequencyValuesList: any = {
    "Minutes": ["10", '20', '30', '40', '50'],
    "Hourly": ["1", '4', '8', '12', '18', '20', '24'],
    "Weekly": ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
    "Daily": ['1', '4', '8', '12', '16', '20', '24'],
    "Monthly": this.getNumbers(12)

  };
  constructor(private api: ProxyService, private dialogRef: MatDialogRef<AdminDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    console.log(data);
    if (data.type === 'frequency') {
      this.frequency = data.frequency;
    }
  }

  private getNumbers(count) {
    const numbersList = [];
    for (let i = 0; i < count; i++) {
      numbersList.push(String(i + 1));
    }
    return numbersList;
  }

  updateFrequency() {
    this.createCronExpression();
    this.dialogRef.close({
      cornValue: this.cornValue,
      frequencyValue: this.frequency.frequencyValue,
      frequencyType: this.frequency.frequencyName     
    });
  }

  closeDialog() {
    this.dialogRef.close(true);
  }

  deleteSystem() {
    this.closeDialog();
  }

  createCronExpression() {
    let expresion = '';
    if (this.frequency.frequencyName === 'Minutes') {
      expresion = `0 0/${this.frequency.frequencyValue} * * * ? `;
    }
    else if (this.frequency.frequencyName === 'Hourly') {
      expresion = `0 0 0/${this.frequency.frequencyValue} * * ? `;
    }
    else if (this.frequency.frequencyName === 'Daily') {
      expresion = `0 0 ${this.frequency.frequencyValue} * * ? `;
    }
    else if (this.frequency.frequencyName === 'Weekly') {
      expresion = `0 0 0 ? * ${this.frequency.frequencyValue} `;
    }
    else {
      expresion = `0 0 0 ? ${this.frequency.frequencyValue} * `;
    }
    this.cornValue= expresion;
  }

  ngOnInit() {
    localStorage.removeItem('data');
    this.frequencyForm = new FormGroup({
      frequencyName: new FormControl('', Validators.required),
      frequencyValue: new FormControl('', Validators.required)
    });
  }
}
