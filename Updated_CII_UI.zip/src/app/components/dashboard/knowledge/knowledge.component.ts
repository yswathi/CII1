import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatSnackBar, MatCheckboxModule } from '@angular/material';
import { environment } from '../../../../environments/environment';
import { ProxyService } from '../../../services/proxy.service';
import { GridOptions } from 'ag-grid'
import { KnowledgeServiceComponent } from './knowledge-servcie/knowledge-service.component';
import { KnowledgeCommentsComponent } from './knowledge-comments/knowledge-comment.component';
import { Router, ActivatedRoute } from '@angular/router';
import { KnowledgeScoreComponent } from './knowledge-score/knowledge-score.component';

@Component({
  selector: 'app-knowledge',
  templateUrl: './knowledge.component.html',
  styleUrls: ['./knowledge.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class KnowledgeComponent implements OnInit {
  private http: HttpClient;
  public gridOptions: GridOptions;
  private snackBar: MatSnackBar;
  public searchInKr: string;
  private dialog: MatDialog;
  public isElastic = true;
  public inProgress = false;
  public customer = 'All';
  public customers: any[] = ['All'];
  public customerList: any ;
  public IsWorkNote: boolean = false;
  public Isexceldisable:boolean = false;
  public gridColumnApi;
  public gridApi;

  WorkNotesRenderer = (params) => {
    if (!this.IsWorkNote) {
      return '';
    }
    else {
      return params.value;
    }
  }
  dateRenderer = (params)=>{
    var date = new Date(params.value);
    return date.toLocaleDateString();
  }
  ratingRenderer = (params) => {
    return this.ratingRendererGeneral(params.value, false);
  }
  commentRenderer = (params) => {
    return this.commentRenderGeneral(params.value, false);
  }
  // onGridSizeChanged(params) {
  //   var gridWidth = document.getElementById("grid-wrapper").offsetWidth;
  //   var columnsToShow = [];
  //   var columnsToHide = [];
  //   var totalColsWidth = 0;
  //   var allColumns = params.columnApi.getAllColumns();
  //   for (var i = 0; i < allColumns.length; i++) {
  //     let column = allColumns[i];
  //     totalColsWidth += column.getMinWidth();
  //     if (totalColsWidth > gridWidth) {
  //       columnsToHide.push(column.colId);
  //     } else {
  //       columnsToShow.push(column.colId);
  //     }
  //   }
  //   params.columnApi.setColumnsVisible(columnsToShow, true);
  //   params.columnApi.setColumnsVisible(columnsToHide, false);
  //   params.api.autoSizeColumns();
  // }
  columnDefs = [];

  public sampleResponse = null;
  public topics = null;
  public topic = null;
  public step = 0;
  public search_results = 0;
  public results_message = '';
  constructor(httpClient: HttpClient, snack: MatSnackBar, private api: ProxyService, matDialog: MatDialog, private route: ActivatedRoute, private router: Router) {
    this.http = httpClient;
    this.snackBar = snack;
    this.dialog = matDialog;
  }
  getColumnDefs() {
    return [
      { headerName: 'Incident Id', field: 'id', width: 135, enableTooltip: true, 
      tooltip: function (params) { return params.valueFormatted ? params.valueFormatted : params.value; },
      cellRenderer: params => {
        return `<a href="javascript:void(0)" class='a_grid'>${
          params.value
          }</a>`;
      }
     },
     {
      headerName: 'Created On',
      field: 'incident_created_at',
      width: 180,
      cellRenderer:this.dateRenderer,
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
    },
      {
        headerName: 'Incident Title',
        field: 'title',
        width: 200, minWidth: 50, maxWidth: 250,suppressSizeToFit: true,
        enableTooltip: true,
        tooltip: function (params) {
          return params.valueFormatted ? params.valueFormatted : params.value;
        }
      },
      {
        headerName: 'Solution',
        field: 'solution',
       
        enableTooltip: true,
        floatCell: true,
        tooltip: function (params) {
          // This will show valueFormatted if is present, if no just show the value.
          return params.valueFormatted ? params.valueFormatted : params.value;
        }
      },
      { headerName: 'Confidence Score', 
        field: 'similarity', 
        width: 150, 
        enableTooltip: true, 
        tooltip: function (params) 
        { 
          let score = params.valueFormatted ? params.valueFormatted : params.value;
          return Math.round(score*100)  + '%';
        },
        cellRenderer: this.scoreRenderer.bind(this)
      },
      

      {
        headerName: "Rating",
        field: "rating",
        width: 150, cellRenderer: this.ratingRenderer.bind(this),
        floatCell: true,
        enableValue: true,
        filterParams: { cellRenderer: 'ratingFilterRenderer' }
      },
      {
        headerName: 'Comments',
        field: 'comments',
        cellRenderer: this.commentRenderer.bind(this),
        width: 160,
        floatCell: true,
        enableValue: true
      },
      {
        headerName: 'Work Notes',
        field: 'work_notes',
        enableTooltip: true,
        hide: !this.IsWorkNote,
        width: 170,
        cellRenderer: this.WorkNotesRenderer.bind(this),
        tooltip: function (params) { return params.valueFormatted ? params.valueFormatted : params.value; }
      },
      
    ];
  }
  ngOnInit() {
    localStorage.removeItem('data');
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 1) {
        this.customers = this.customers.concat(res);
      } else {
        this.customers = res;
        this.customer = res[0];
      }
    }, error => {
    });
    // this.gridOptions.api.sizeColumnsToFit();

  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  goSearch(event) {
    if (event.keyCode === 13 || event.which === 13) {
       this.Isexceldisable = !this.searchInKr ? false: true;
      this.getKRResults();
    }
  }
  onSearchChange(searchValue : string ) {  
  }
  prevStep() {
    this.step--;
  }

  private ratingFilterRenderer(params) {
    return this.ratingRendererGeneral(params.value, true)
  }

  private commentRenderGeneral(value, forFilter) {
    if (value.length > 0) {
      return `<span><i class="fa fa-comments " style="color:green;" aria-hidden="true"></i>(${value.length})</span>`;
    }
    else {
      return '<i class="fa fa-comments " aria-hidden="true"></i>';
    }

  }
  private ratingRendererGeneral(value, forFilter) {
    /*var result = '<span>';
    for (var i = 0; i < 5; i++) {
        if (value > i) {
            result += '<img src="assets/star.svg" class="star" width=12 height=12 />';
        }
    }
    if (forFilter && value === 0) {
        result += '(no stars)';
    }
    result += '</span>';
    return result;*/
    return '<div class="stars-outer"><div class="stars-inner" style="width: ' + (value / 5 * 100) + '%"></div></div>';

  }

  private scoreRenderer(value){
    const score =  Math.round(value.value* 100);
    return `<div>${score}%</div>`
  }
  
  onCellClicked(event) {
    if (event.colDef.headerName === 'Rating') {
      //this.openDialog(event.data, true);
      const dialogRef = this.dialog.open(KnowledgeServiceComponent, {
        width: '800px',
        height: '400px',
        hasBackdrop: true,
        data: {
          serviceData: event.data ? event.data : [],
        },
        disableClose: true
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.inProgress = true;
          const interval = setInterval(() => { 
            this.getKRResults(); 
            clearInterval(interval)
        },500);
        }
      });
    } else if (event.colDef.headerName === 'Comments') {
      const dialogRef = this.dialog.open(KnowledgeCommentsComponent, {
        width: '800px',
        height: '400px',
        hasBackdrop: true,
        data: {
          serviceData: event.data ? event.data : [],
        },
        disableClose: true
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.inProgress = true;
          const interval = setInterval(() => { 
            this.getKRResults(); 
            clearInterval(interval)
        },500);
        }
      });
    } else if(event.colDef.headerName === 'Incident Id'){
        const dialogRef = this.dialog.open(KnowledgeScoreComponent, {
          width: '800px',
          maxHeight: '400px',
          hasBackdrop: true,
          data: {
            serviceData: event.data ? event.data :[],
            disableClose: true,
          }
        })
    }
  }

  private getWorkNoteType() {
    return this.IsWorkNote ? 'n' : 'y';
  }
  private getKnowledgeResults() {
    const searchonTitle = this.getWorkNoteType();
    const isElasticOn = false;
    this.columnDefs = this.getColumnDefs();
    let payload:any ={
      searchOnTitle:searchonTitle,
      searchText:this.searchInKr,
      elasticOn:this.isElastic,
      customers:this.customerList
    }
    return this.api.post(
      `${environment.backendDomain}ims/externalService/kr/search`,
      payload
    )
    
  }
  private getElasticResults() {
    const searchOnTitle = this.getWorkNoteType();
    const isElasticOn = true;
    this.columnDefs = this.getColumnDefs();
    let payload:any ={
      searchOnTitle:searchOnTitle,
      searchText:this.searchInKr,
      elasticOn:this.isElastic,
      customers:this.customerList
    }
    return this.api.post(
      `${environment.backendDomain}ims/externalService/kr/search`,
      payload
    )
  }
  private clearOldData() {
    this.sampleResponse = null;
    this.topics = null;
    this.topic = null;
  }
  public getKRResults() {
    if (this.customer === 'All') {
      let arr = this.customers.filter(function (e) { return e !== 'All' });
      this.customerList = arr;
    } else {
      let array=[];
      array.push(this.customer)
      this.customerList = array;
    }
    this.Isexceldisable = !this.searchInKr ? false: true;
    this.inProgress = true;
    // this.Isexceldisable = true;
    this.clearOldData();

    const result = !this.isElastic
      ? this.getElasticResults()
      : this.getKnowledgeResults();
    result.subscribe(
      response => {
        if (response && !response.hasOwnProperty('statusCode')) {
          this.sampleResponse = response;
          this.topics = this.sampleResponse.response.search_response;
          this.search_results = this.sampleResponse.response.results_count;
          if (this.search_results === 0) {
            this.topic = null;
            this.results_message = this.sampleResponse.response.ERROR;
          } else {
            this.topic = this.topics[0];
            this.results_message = '';
          }
          this.inProgress = false;
        } else {
          this.topics = [];
          this.topic = null;
          this.search_results = 0;
          this.results_message = 'No Results Found';
          this.inProgress = false;
        }

      },
      response => {
        this.snackBar.open('Search Failed !', 'Operation', { duration: 10000 });
        this.inProgress = false;
      }
    );
  }
  Exportsearch(): void {
    const searchOnTitle = this.getWorkNoteType();
    let payload: any = {
      searchOnTitle:searchOnTitle,
      searchText:this.searchInKr,
      customers:this.customerList,
      elasticOn:this.isElastic
    };
    this.api
    .postdata(
      `${environment.backendDomain}ims/externalService/kr/search/export`,
      payload
    )
    .subscribe(res => {
      var a = document.createElement("a");
          a.href = URL.createObjectURL(new Blob([res.body], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}));
          a.download = 'SearchResults';
          // start download
          a.click();
    });
}
}
