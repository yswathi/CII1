import { Component, OnInit, Inject ,ElementRef, ViewChild,OnChanges, SimpleChanges} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA,MatSnackBar } from '@angular/material';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import * as _ from 'underscore';
@Component({
    selector: 'knowledge-score',
    templateUrl: './knowledge-score.component.html',
    styleUrls: ['./knowledge-score.component.scss'],
  })

  export class KnowledgeScoreComponent implements OnInit {
      displayData: string= "";
      serviceData: any =[];
    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private api : ProxyService,
    private dialogRef: MatDialogRef<KnowledgeScoreComponent>,
    private snack: MatSnackBar) {
       this.displayData =  this.data.serviceData.solution
       this.serviceData = this.data.serviceData;
       this.displayData = this.serviceData.solution;
    }


    ngOnInit(){
        this.displayData =  this.data.serviceData.solution
    }
  }