import { Component, OnInit, Inject ,ElementRef, ViewChild,OnChanges, SimpleChanges} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA,MatSnackBar } from '@angular/material';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import * as _ from 'underscore';
@Component({
  selector: 'knowledge-service-rating',
  templateUrl: './knowledge-service.component.html',
  styleUrls: ['./knowledge-service.component.scss']
})
export class KnowledgeServiceComponent implements OnInit{
  ratings: Array<number> = [1,2,3,4,5];
  updatedRating : number;
  knowledgeForm: FormGroup;
  ratingData: Array<any>;
  totalData: any;
  isFormVisible : boolean = false;
  snackBar: MatSnackBar;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private api : ProxyService,
    private dialogRef: MatDialogRef<KnowledgeServiceComponent>,
    private snack: MatSnackBar){
    this.totalData = this.data.serviceData;
    this.ratingData = this.data.serviceData.ratings;
    this.snackBar = snack;
  }
  addRating(){
    this.isFormVisible = true;
  }
  addUpdateServer(){
    const customer = this.data.serviceData.customer;
    this.api
      .get(`${environment.backendDomain}ims/externalService/${customer}/${this.totalData.id}/kr/rating?rating=${this.updatedRating}`)
      .subscribe((res: string) => {
        if (res == "SUCCESS") {
          res = `Rating(s) updated successfully`;
        }

        this.snackBar.open(res, null, {
          duration: 3000
        });
        this.dialogRef.close(true);
      });
  }
  ngOnInit(){
    this.knowledgeForm = new FormGroup({
      rating: new FormControl({ value: '' }, Validators.required)
    });
  }

}
