import { Component, OnInit } from '@angular/core';
import { TableauService } from '../../../../shared/tableau.service';
import { environment } from '../../../../environments/environment';
import { ProxyService } from '../../../services';

declare var tableauSoftware: any;
declare var tableauViz, activeSheet, workbook;

@Component({
  selector: 'app-value',
  templateUrl: './value.component.html',
  styleUrls: ['./value.component.scss']
})

export class ValueComponent implements OnInit {
  constructor(private tableauService: TableauService, private api: ProxyService) { }
  customers: any = [];
  selectedCustomer: any;
  placeholderDiv: any;
  urlString: string;
  tableauViz: any;
  filterValues: any;
  listofCustomers = ['Airgas'];
  
  customerChange(value) {
   if(this.tableauViz) {
    this.tableauViz.dispose();
   }
    this.selectedCustomer = value;
    // if (value === 'All') {
    //   this.filterValues = this.customers;
    // } else {
    // this.filterValues = value;
    //   }

    // let filterObj  = {
    //   Customer: this.filterValues
    // };
    this.getUrls();
    // this.setTableauViz(this.placeholderDiv, this.urlString);
  }


  //    applyToDetailed() {
  //     var workSheets = this.tableauViz.getWorkbook().getActiveSheet().getWorksheets(); 
  //     for (var i = 0; i <= workSheets.length - 1; i++) {
  // //    if(workSheets[i].getName().indexOf('_nofilter') === -1) {
  //         workSheets[i].applyFilterAsync("Customer", this.filterValues, 'REPLACE');
  //   //  }
  //     } 
  //     }



  setTableauViz(element: any, urlString: string) {
    var options = {
      width: '1350px',
      height: '750px',
      hideTabs: false,
      hideToolbar: true,
      Customer: this.selectedCustomer,
      onFirstInteractive: function () {
        
        // workbook = this.tableauViz.getWorkbook();
        // activeSheet = workbook.getActiveSheet().getWorksheets().get("Forecast")
      }
    };
    this.tableauViz = new tableauSoftware.Viz(element, urlString, options);
  };

  ngOnInit() {
    // this.tableauViz.dispose();
    localStorage.removeItem('data');

    // https://tableau.internal.deloitte.com/views/CIIDashboardProd/ForecastSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no 
    this.placeholderDiv = document.getElementById("tableauViz-amsi");
    this.getcustomers();
    //  this.api.get(`${environment.backendDomain}ims/configuration/tableau`).subscribe(res =>{
    //   this.urlString = res.CII;
    //   this.getcustomers();

    // })
    // //  this.urlString = 'https://tableau.internal.deloitte.com/views/CIIDashboardProd/ForecastSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';--This is for snetprod
    //  //'https://tableau.internal.deloitte.com/views/CIIDashboardProd/ForecastSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';
    //  // "http://192.168.204.234/views/CIIDashboard/ForecastSummary?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
    //  this.urlString = ' https://tableau.internal.deloitte.com/views/CIIDashboard/ForecastSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';//This is for snetdev//



    // }


  }
  getcustomers() {
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 0) {
        this.customers = res;
        // this.listofCustomers =res;
        if (this.selectedCustomer == null || this.selectedCustomer === undefined) {
          this.selectedCustomer = this.customers[0];
        }
      } else {
        this.customers = [];
        this.filterValues = '';
      }
      this.getUrls();

    }, error => {
    });
  }
  getUrls() {
    this.api.post(
      `${environment.backendDomain}ims/configuration/tableau/getUrls`,
      this.customers
    ).subscribe(res => {
      if (res[this.selectedCustomer]) {
        // this.urlString = res[this.selectedCustomer][0].AMSI;
        for (let i = 0; i < res[this.selectedCustomer].length; i++) {
          if (Object.keys(res[this.selectedCustomer][i])[0] === 'AMSI') {
          this.urlString = res[this.selectedCustomer][i].AMSI;
          }
          }
        this.setTableauViz(this.placeholderDiv, this.urlString);
      };
      // this.urlString = res.CII;

    })
  }
}