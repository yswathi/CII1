import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';
import { LoaderService } from '../../app/loader/loader.service';
import { Router } from '@angular/router';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
//import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { PpmComponent } from './ppm.component';

describe(' PpmComponent', () => {
  let fixture: ComponentFixture<PpmComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [PpmComponent],
      imports: [
        HttpClientTestingModule,
        MatDatepickerModule,
        MatNativeDateModule,
        RouterTestingModule
      ],
      providers: [
        { provide: ProxyService, useClass: ProxyService },
        { provide: LoaderService, useClass: LoaderService },
        { provide: DatePipe, useClass: DatePipe }
      ]
    }).compileComponents();
    var todayList = [];
    var yesterdayList = [];
    var olderList = [];
    var yestDay = [];
    fixture = TestBed.createComponent(PpmComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', () => {
    expect(fixture).toBeTruthy();
    expect(app).toBeDefined();
  });
  it('should have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should have setStep()', async(() => {
    expect(app.setStep).toBeDefined();
    app.setStep();
  }));
  it('should have cellTriggered()', async(() => {
    expect(app.cellTriggered).toBeDefined();
    app.cellTriggered();
  }));
});
