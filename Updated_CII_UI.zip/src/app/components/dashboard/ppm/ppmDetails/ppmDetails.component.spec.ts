import { Component, OnInit, Renderer } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';
import { LoaderService } from '../../../app/loader/loader.service';
import { Router, ActivatedRoute } from '@angular/router';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { PpmDetailsComponent } from './ppmDetails.component';
describe(' PpmDetailsComponent', () => {
  let fixture: ComponentFixture<PpmDetailsComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [PpmDetailsComponent],
      imports: [
        HttpClientTestingModule,
        MatDatepickerModule,
        MatNativeDateModule,
        RouterTestingModule
      ],
      providers: [
        { provide: ProxyService, useClass: ProxyService },
        { provide: LoaderService, useClass: LoaderService },
        { provide: DatePipe, useClass: DatePipe }
      ]
    }).compileComponents();
    var params;
    fixture = TestBed.createComponent(PpmDetailsComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', () => {
    expect(fixture).toBeTruthy();
    expect(app).toBeDefined();
  });
  it('should have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should have  getDetails()', async(() => {
    expect(app.getDetails).toBeDefined();
    app.getDetails();
  }));
  it('should have ngOnDestroy()', async(() => {
    expect(app.ngOnDestroy).toBeDefined();
    app.ngOnDestroy();
  }));
  it('should have goBack()', async(() => {
    expect(app.goBack).toBeDefined();
    app.goBack();
  }));
});
