import { UserService } from './../../../services/user.service';
import { element } from 'protractor';
import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild, Input, ViewEncapsulation } from '@angular/core';
import * as c3 from 'c3';
import {  Router, ActivatedRoute} from '@angular/router';



@Component({
    selector: 'app-horizontal-bar-chart',
    templateUrl: './horizontal-bar-chart.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./horizontal-bar-chart.component.scss']
})
export class HorizontalBarChartComponent implements OnInit {
    @Input() id;
    @Input() bardata;
    @Input() selectedDepartment: string;
    graphHeight;
    coloum;
    // colors={
    //     data1: '#ff0000',
    //     data2: '#00ff00',
    // };
    constructor(private router:Router,private UserService:UserService){
        
            }
    ngOnInit() {
        const colums = this.prepareColums(this.bardata);
        this.graphHeight = colums[0].length * 30;
        setTimeout(() => {
            var chart = c3.generate({
                bindto: '#' + this.id,
                padding: {
                    left: 250,
                    right: 100,
                    top: 2,
                    bottom: 2
                },
                size: {
                    height: this.graphHeight
                },
                bar: {
                    width: 20,
                    spacing: 2
                },
                data: {
                    x: 'x',
                    labels: true,
                    columns: colums,
                    onclick: (d,index)=> { 
                        let data =this.UserService.getDetaildatappm();
                        data.department=this.coloum[0][d.index +1];
                        data.value= d.value;
                        this.UserService.setDetaildatappm(data);
                        this.router.navigateByUrl('/dashboard/detailedppm');
                     },
                    type: 'bar',
                    groups:[['Valid','Invalid']],
                    colors: {
                        Valid: '#72b965',
                        Invalid: '#6b6666',
                    }
                },
                axis: {
                    rotated: true,
                    x: {
                        type: 'category',
                        tick:{
                            multiline: false,
                        }
                    }
                },
                tooltip: {
                    grouped: false,
                   
                },
                legend: {
                    show: false
                },
            });
        }, 20)
     


    }


    prepareColums(data) {
           this.coloum = [['x'], ['Valid'], ['Invalid']]
        if (data && data.length) {
            data.forEach(element => {
                this.coloum[0].push(element.department);
                this.coloum[1].push(element.valueTrue);
                if ( element.valueFalse === 0 ){
                    element.valueFalse = null
                }
                this.coloum[2].push(element.valueFalse);
            });
        }
        return this.coloum;

    }

}
