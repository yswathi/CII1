import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-denied',
  templateUrl: './accessDenied.component.html',
  styleUrls: ['./accessDenied.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AccessDeniedComponent implements OnInit {
    constructor(){

    }
    ngOnInit() {


        }

}