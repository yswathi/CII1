import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { AmsiComponent } from './amsi.component';

describe('AmsiComponent', () => {
  let app: any;
  let fixture: ComponentFixture<AmsiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AmsiComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(AmsiComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
});
