import { Component, OnInit } from '@angular/core'
import { environment } from '../../../../environments/environment';
import { TableauService } from '../../../../shared/tableau.service';
import { ProxyService } from '../../../services';
declare var tableauSoftware: any;
declare var tableauViz, activeSheet, workbook;

@Component({
  selector: 'app-amsi',
  templateUrl: './amsi.component.html',
  styleUrls: ['./amsi.component.scss']
})

export class AmsiComponent implements OnInit {

  tableauViz: any;
  workbook: any;
  activeSheet: any;
  customers: any = [];
  selectedCustomer: any;
  placeholderDiv: any;
  urlString: string;
  filterValues: any;

  constructor(private api: ProxyService) {}

  customerChange(value) {
    this.tableauViz.dispose();
    this.selectedCustomer = value;
    // if (value === 'All') {
    //   this.filterValues = this.customers;
    // } else {
      this.filterValues = value;
 //   }

    let filterObj  = {
      Customer: this.filterValues
    };

    this.setTableauViz(this.placeholderDiv, this.urlString, filterObj);
  }

  setTableauViz(element: any, urlString: string, filterObj) {
    var options = {
      width: '1350px',
      height: '750px',
      hideTabs: true,
      hideToolbar: true,
      onFirstInteractive: function () {
       
      }
    };
    if(filterObj){
      options = Object.assign({}, options, filterObj);
    }
    this.tableauViz = new tableauSoftware.Viz(element, urlString, options);
  };

  getCustomers(){
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 0) {
        this.customers = res;
        if (this.selectedCustomer == null || this.selectedCustomer === undefined) {
          this.selectedCustomer = this.customers[0];
          this.filterValues = this.selectedCustomer;
        }
      } else {
        this.customers = [];
        this.filterValues = '';
      }

      let filterObj = {
        Customer: this.filterValues
      } 

      this.setTableauViz(this.placeholderDiv, this.urlString, filterObj);
     
    }, error => {
    });
  }
  

  ngOnInit() {
    localStorage.removeItem('data');
    this.placeholderDiv = document.getElementById("tableauViz-amsi");
    this.api.get(`${environment.backendDomain}ims/configuration/tableau`).subscribe(res =>{
      this.urlString = res.FORECAST;
      this.getCustomers();
    })
  }
  //  //  https://tableau.internal.deloitte.com/views/CIIDashboardProd/Home?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no
  //   this.urlString = "http://216.218.209.104:8000/views/CIIDashboard/ForecastSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no"
  //   //"http://192.168.204.234/views/CIIDashboard/Home?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
  //   // this.urlString = "https://tableau.internal.deloitte.com/views/CIIDashboard/Home?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no"  //This is for snetdev
  //   this.getCustomers();
  // }
}