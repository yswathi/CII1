import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { ValueComponentppm } from '../ppmdash/ppmdash.component';

describe('ValueComponentppm', () => {
  let app: any;
  let fixture: ComponentFixture<ValueComponentppm>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ValueComponentppm]
    }).compileComponents();
    fixture = TestBed.createComponent(ValueComponentppm);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
});
