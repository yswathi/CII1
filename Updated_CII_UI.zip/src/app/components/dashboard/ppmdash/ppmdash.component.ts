import { UserService } from './../../../services/user.service';
import { Validators } from '@angular/forms';
import { element } from 'protractor';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RequestOptions, Headers } from "@angular/http";
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import { TableauService } from '../../../../shared/tableau.service';
import { MatSliderModule } from '@angular/material/slider';
import { Subject } from 'rxjs/Subject';
declare var tableauSoftware: any;
declare var tableauViz, activeSheet, workbook;

@Component({
  selector: 'app-ppmdash',
  templateUrl: './ppmdash.component.html',
  styleUrls: ['./ppmdash.component.scss']
})
export class ValueComponentppm implements OnInit {

  constructor(private tableauService: TableauService, private api: ProxyService, private UserService: UserService) { }
  customers: any = [];
  selectedCustomer: any;
  selectedDepartment: any;
  departments: any = [];
  Departments;
  placeholderDiv: any;
  urlString: string;
  tableauViz: any;
  filterValues: any;
  selectedproblemType = 'Technical';
  disable: boolean = false;
  public inProgress = false;
  problemdata: any[] = [];
  incidentdata: any = [];
  public totalproblemcount;
  public totalincidentcount;
  public valid: boolean = false;
  public minThreshHold = 3;
  public chartcontent = false;
  private rangeTerm = new Subject<any>();

  dataset = {
    target: 'Dchart1',
    categories: 'accepted',
    height: 300,
    title: this.totalproblemcount,
    data: [
      {
        accepted: this.totalproblemcount
      },

    ],

  };
  sdataset = {
    target: 'Dchart2',
    categories: 'accepted',
    height: 300,
    title: this.totalincidentcount,
    data: [
      {
        accepted: this.totalincidentcount
      },

    ],

  };
  onInputChange(e) {
    this.problemdata = [];
    this.incidentdata = [];
    this.totalincidentcount = '';
    this.totalproblemcount = ''
    this.minThreshHold = e.target.value;
    this.api.url = `${environment.backendDomain}ims/dashboard/ppm`;
    this.api.payload = {
      "valid": this.valid,
      "customer": this.selectedCustomer,
      "problemType": this.selectedproblemType,
      "minThreshHold": this.minThreshHold,
      'department': this.selectedDepartment
    }
    this.rangeTerm.next(e);
    //this.getDashboarddata();
  
  }
  customerChange(e) {
    this.minThreshHold = 3;
    this.problemdata = [];
    this.incidentdata = [];
    this.Departments = []
    // this.tableauViz.dispose();
    this.selectedCustomer = e;
    this.selectedDepartment = 'All'
    this.UserService.setDepartment(this.selectedDepartment)
    this.getDepartments();
    this.getDashboarddata();
    // if (value === 'All') {
    //   this.filterValues = this.customers;
    // } else {
    // this.filterValues = value;
    //   }

    // let filterObj  = {
    //   Customer: this.filterValues
    // };

    // this.setTableauViz(this.placeholderDiv, this.urlString, filterObj);
  }
  toggle(e) {
    this.problemdata = [];
    this.incidentdata = [];
    this.totalincidentcount = '';
    this.totalproblemcount = ''
    this.valid = e.checked;
    this.getDashboarddata();
  }
  departmentChange(e) {
    this.problemdata = [];
    this.incidentdata = [];
    this.totalincidentcount = '';
    this.totalproblemcount = ''
    this.selectedDepartment = e;
    this.UserService.setDepartment(this.selectedDepartment)
    this.getDashboarddata();
  }
  selectedproblemTypeChange(e) {
    this.problemdata = [];
    this.incidentdata = [];
    this.totalincidentcount = '';
    this.totalproblemcount = ''
    this.selectedproblemType = e;
    this.getDashboarddata();
  }
  getDepartments() {
    this.inProgress = true;
    this.disable = true;
    this.api.get(`${environment.backendDomain}ims/dashboard/ppm/` + this.selectedCustomer + `/departments`).subscribe(res => {
      setTimeout(function () {
        this.disable = false;
      }, 100)

      this.inProgress = false;
      // this.getDashboarddata();
      if (res.department_list.length > 0) {
        res.department_list.forEach(element => {
          this.departments.push(element);
        });

        if (this.departments.length > 0) {
          // this.selectedDepartment = 'All';
          this.Departments = this.departments
          this.departments = [];
        }

      } else {
        this.departments = [];
        //this.selectedDepartment='All'
        // this.filterValues = '';
      }

      // let filterObj = {
      //   Customer: this.filterValues
      // } 

      // this.setTableauViz(this.placeholderDiv, this.urlString, filterObj);

    }, error => {
    });
  }

  getCustomers() {
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 0) {
        this.customers = res;
        if (this.selectedCustomer == null || this.selectedCustomer === undefined) {
          let x = JSON.parse(localStorage.getItem('data'))
          if (x == null || x == undefined) {
            this.selectedCustomer = this.customers[0];
            // this.filterValues = this.selectedCustomer;
            // this.selectedDepartment = 'All';
            this.getDepartments();
            this.getDashboarddata();
          } else {
            let x = localStorage.getItem("data");
            this.selectedCustomer = JSON.parse(x).customer;
            this.selectedproblemType = this.validRenderer(JSON.parse(x).problemType);
            this.minThreshHold = JSON.parse(x).minThreshHold;
            this.valid = JSON.parse(x).valid
            // this.selectedDepartment = JSON.parse(x).department;
            this.getDepartments();
            this.getDashboarddata();
          }

        }
      } else {

        this.customers = [];
        this.filterValues = '';
      }

      // let filterObj = {
      //   Customer: this.filterValues
      // } 

      // this.setTableauViz(this.placeholderDiv, this.urlString, filterObj);

    }, error => {
    });
  }
  getDashboarddata() {
    this.inProgress = true;
    let dpt = this.UserService.getDepartment();
    console.log(dpt)
    let x = JSON.parse(localStorage.getItem('data'));
    // this.disable=false;
    if (x == null || x == undefined || dpt == undefined) {
      this.selectedDepartment = 'All'
    } else {
      let x = localStorage.getItem("data");
      this.selectedDepartment = dpt;
    }
    // this.getCustomers();
    this.problemdata.length = 0;
    let payload: any = {

      "valid": this.valid,
      "customer": this.selectedCustomer,
      "problemType": this.selectedproblemType,
      "minThreshHold": this.minThreshHold,
      'department': this.selectedDepartment
    }
    return this.api.post(
      `${environment.backendDomain}ims/dashboard/ppm`,
      payload
    ).subscribe(
      res => {
        // this.UserService.setDetaildatappm(payload);
        this.inProgress = false;
        this.chartcontent = true;
        if (res && res.response && res.response.incident_count && res.response.dept_problem_count) {
          this.totalincidentcount = res.response.incident_count;
          this.totalproblemcount = res.response.problems_count;
          res.response.dept_problem_count.forEach(element => {
            this.problemdata.push({ 'department': element['department'], 'valueTrue': element['true_count'], 'valueFalse': element['false_count'] });
          });
          res.response.dept_incident_cnt.forEach(element => {
            this.incidentdata.push({ 'department': element['department'], 'valueTrue': element['true_count'], 'valueFalse': element['false_count'] })
          });
          payload.totalProblemcount = this.totalproblemcount;
          this.UserService.setDetaildatappm(payload);
          this.dataset = {
            target: 'Dchart1',
            categories: 'accepted',
            height: 200,
            title: this.totalproblemcount,
            data: [
              {
                accepted: this.totalproblemcount
              },

            ],

          };
          this.sdataset = {
            target: 'Dchart2',
            categories: 'accepted',
            height: 200,
            title: this.totalincidentcount,
            data: [
              {
                accepted: this.totalincidentcount
              },

            ],

          };


        }

        // res.response.dept_incident_cnt.forEach(element => {
        //   let a;
        //   a.push(element.key);
        // console.log(a);
        // });
      })
    //   this.api.get(`${environment.backendDomain}ims/dashboard/ppm`).subscribe(res => {
    //    console.log(res);
    //    if(res.incidentsByDepartment!=''){
    //     res.incidentsByDepartment.forEach(element => {
    //       var data=[];
    //       this.chartData.push({'name':element['department'],'value':element['problemcount']});
    //      });
    //    }console.log(this.chartData);
    // })

  }
  // Updatedata(e){
  //   console.log(e)
  //   if(e=="yes"){
  //     return this.chartData=[
  //       {
  //         name: "AMS Business Warehouse", value: "68"
  //       }
  //       ,{
  //         name: "AMS Dev",
  //         value: "1"
  //       },
  //         {
  //           name: "AMS Finance",
  //           value: "382"
  //       }
  //       ,{
  //         name: "AMS Order Management",
  //         value: "633"
  //       }
  //       , {
  //         name: "AMS Security",
  //         value: "262"
  //       }
  //       ,{
  //         name: "AMS Supply Chain",
  //         value: "211"
  //       }
  //       ,{
  //         name: "AMS Technical Infrastructure and Basis",
  //         value: "961"
  //       }
  //     ];
  //   }
  // }
  validRenderer = (params) => {
    let x = params;
    let y = x.toString()
    return y.charAt(0).toUpperCase() + y.slice(1);
  }
  ngOnInit() {
    this.placeholderDiv = document.getElementById("tableauViz-ppm-forecast");
    this.api.get(`${environment.backendDomain}ims/configuration/tableau`).subscribe(res => {
      this.urlString = res.PPM;
      this.getCustomers();
      // this.getDashboarddata();
      // this.getDepartments();

    })
    this.api.search(this.rangeTerm)
      .subscribe(res => {
        // this.UserService.setDetaildatappm(payload);
        this.inProgress = false;
        this.chartcontent = true;
        if (res && res.response && res.response.incident_count && res.response.dept_problem_count) {
          this.totalincidentcount = res.response.incident_count;
          this.totalproblemcount = res.response.problems_count;
          res.response.dept_problem_count.forEach(element => {
            this.problemdata.push({ 'department': element['department'], 'valueTrue': element['true_count'], 'valueFalse': element['false_count'] });
          });
          res.response.dept_incident_cnt.forEach(element => {
            this.incidentdata.push({ 'department': element['department'], 'valueTrue': element['true_count'], 'valueFalse': element['false_count'] })
          });
          this.api.payload.totalProblemcount = this.totalproblemcount;
          this.UserService.setDetaildatappm(this.api.payload);
          this.dataset = {
            target: 'Dchart1',
            categories: 'accepted',
            height: 200,
            title: this.totalproblemcount,
            data: [
              {
                accepted: this.totalproblemcount
              },

            ],

          };
          this.sdataset = {
            target: 'Dchart2',
            categories: 'accepted',
            height: 200,
            title: this.totalincidentcount,
            data: [
              {
                accepted: this.totalincidentcount
              },

            ],

          };


        }

        // res.response.dept_incident_cnt.forEach(element => {
        //   let a;
        //   a.push(element.key);
        // console.log(a);
        // });
      });
    //  // https://tableau.internal.deloitte.com/views/PPMDashboardProd/HomeDashboard?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no
    //    this.urlString = 'http://216.218.209.104:8000/views/PPMDashboard/HomeDashboard?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';  
    //   // 'http://192.168.204.234/views/PPMDashboard/HomeDashboard?:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';
    //   // this.urlString = 'https://tableau.internal.deloitte.com/views/PPMDashboard/HomeDashboard?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no';  // This is for snetdev

    //   this.getCustomers();
  }


}
