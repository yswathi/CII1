import { Component, OnInit, Inject ,ElementRef, ViewChild,OnChanges, SimpleChanges} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA,MatSnackBar } from '@angular/material';
import { ProxyService } from '../../../../../services/proxy.service';
import { environment } from '../../../../../../environments/environment';
import { Params } from '@angular/router';
import * as _ from 'underscore';
@Component({
    selector: 'validupdate',
    templateUrl: './vaildupdate.component.html',
    styleUrls: ['./vaildupdate.component.scss'],
  })

  export class ValidComponent implements OnInit {
    public params: any;
    constructor(){}
    agInit(params: any): void {
    }
    ngOnInit(){
        
    }
  }