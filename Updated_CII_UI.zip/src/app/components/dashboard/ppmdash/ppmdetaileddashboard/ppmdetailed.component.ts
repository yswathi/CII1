import { ValidComponent } from './vaildupdate/validupdate.component';
import { EditComponent } from './edit-ppmdetails/edit.component';
import { UserService } from './../../../../services/user.service';
import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TitleCasePipe } from '@angular/common';
import {  Router, ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-about',
  templateUrl: './ppmdetailed.component.html',
  styleUrls: ['./ppmdetailed.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers:[TitleCasePipe]
})
export class DetailedDashboardComponent implements OnInit {
    // private gridApi;
    // private gridColumnApi;
    public apiRequsteddata; 
    public columnDefs;
    public columnDefs1;
    private dialog: MatDialog;
    public problemData;
    public incidentData;
    public department;
    public inProgress:boolean = false;
    public problemcount;
    public totalProblemcount
    constructor(private api: ProxyService,private router:Router,private UserService:UserService, matDialog: MatDialog,private TitleCasePipe:TitleCasePipe){
        this.dialog = matDialog;
    }
    getColumnDefs() {
        return [
          { headerName: 'Problem Id', field: 'problem_id', width: 120, enableTooltip: true, 
          tooltip: function (params) { return params.valueFormatted ? params.valueFormatted : params.value; },
          cellRenderer: params => {
            return `<a href="javascript:void(0)" class='a_grid'>${
              params.value
              }</a>`;
          }
         },
         {
            headerName: 'Problem Description',
            field: 'problem_description',
            width: 410,
          
            enableTooltip: true,
            tooltip: function (params) {
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
         {
          headerName: 'Created Date',
          field: 'created_at',
          width: 150,
          cellRenderer: this.dateRenderer,
          enableTooltip: true,
          tooltip: function (params) {
            var date = new Date(params.value);
            // This will show valueFormatted if is present, if no just show the value.
            return params.valueFormatted ? params.valueFormatted :date.toLocaleDateString();
          }
        },
          {
            headerName: 'Last modified Date',
            field: 'last_modified_date',
            width: 160, 
            cellRenderer: this.dateRenderer,
            enableTooltip: true,
            tooltip: function (params) {
              var date = new Date(params.value);
              // This will show valueFormatted if is present, if no just show the value.
              return params.valueFormatted ? params.valueFormatted :date.toLocaleDateString();
            }
          },
          {
            headerName: 'Incidents',
            field: 'incidents',
            width: 120,
            enableTooltip: true,
            tooltip: function (params) {
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
          {
            headerName: 'Total Incidents',
            field: 'total_incidents',
            width: 150,
            enableTooltip: true,
            floatCell: true,
            tooltip: function (params) {
          
              // This will show valueFormatted if is present, if no just show the value.
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
          {
            headerName: 'Valid',
            field: 'valid',
            cellRenderer: this.validRenderer,
            enableTooltip: true,
            width: 110,
            floatCell: true,
            tooltip: function (params) {
              let x= params.value;
              let y =x.toString()
              let l= y.charAt(0).toUpperCase() + y.slice(1)
              // This will show valueFormatted if is present, if no just show the value.
              return params.valueFormatted ? params.valueFormatted : l;
            }
          },
          {
            headerName: 'ITSM Problem Id',
            field: 'itsm_problem_id',
            width: 160,
            enableTooltip: true,
            floatCell: true,
            tooltip: function (params) {
          
              // This will show valueFormatted if is present, if no just show the value.
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          }
        ];
      }
    getColumnDefs1() {
        return [
          { headerName: 'Incident ID', field: 'incident_id', width: 130, enableTooltip: true, 
          tooltip: function (params) { return params.valueFormatted ? params.valueFormatted : params.value; },
          // cellRenderer: params => {
          //   return `<a href="javascript:void(0)" class='a_grid'>${
          //     params.value
          //     }</a>`;
          // }
         },
         {
            headerName: 'Problem Description',
            field: 'problem_description',
            width: 300,
          
            enableTooltip: true,
            tooltip: function (params) {
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
         {
          headerName: 'Assignment Group',
          field: 'department',
          width: 180,
        
          enableTooltip: true,
          tooltip: function (params) {
            return params.valueFormatted ? params.valueFormatted : params.value;
          }
        },
          {
            headerName: 'Title',
            field: 'title',
            width: 210,
            enableTooltip: true,
            tooltip: function (params) {
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
          {
            headerName: 'Solution',
            field: 'solution',
            width: 160,
            enableTooltip: true,
            tooltip: function (params) {
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
          {
            headerName: 'Work Notes',
            field: 'work_notes',
            width: 160,
            enableTooltip: true,
            floatCell: true,
            tooltip: function (params) {
              // This will show valueFormatted if is present, if no just show the value.
              return params.valueFormatted ? params.valueFormatted : params.value;
            }
          },
          {
            headerName: 'Created On',
            field: 'open_time',
            width: 120,
            cellRenderer: this.dateRenderer,
            enableTooltip: true,
            floatCell: true,
            tooltip: function (params) {
              var date = new Date(params.value);
              // This will show valueFormatted if is present, if no just show the value.
              return params.valueFormatted ? params.valueFormatted :  date.toLocaleDateString();
            }
          },
          {
            headerName: 'Closed',
            field: 'closed_time',
            width: 120,
            cellRenderer: this.dateRenderer,
            enableTooltip: true,
            floatCell: true,
            tooltip: function (params) {
              var date = new Date(params.value);
              
              // This will show valueFormatted if is present, if no just show the value.
              return params.value=='' ? '' :date.toLocaleDateString();
            }
          },
        ];
      }
      nevigatedashboard(){
        this.router.navigateByUrl('/dashboard/ppmdash');
      }
    ngOnInit() {
        this.gettableData();
        this.columnDefs= this.getColumnDefs();
        this.columnDefs1 = this.getColumnDefs1();
    }
    dateRenderer = (params)=>{
      if(params.value==''){
        return ''
      }else{
      var date = new Date(params.value);
      return date.toLocaleDateString();
      }
    }
    validRenderer=(params)=>{
      let x= params.value;
      let y =x.toString()
      return y.charAt(0).toUpperCase() + y.slice(1);
    }
    gettableData(){
      this.inProgress = false;
      let x=localStorage.getItem("data");
        this.apiRequsteddata= JSON.parse(x)
        // this.UserService.setDetaildatappm(this.apiRequsteddata);
        this.department= this.apiRequsteddata.department;
        this.problemcount = this.apiRequsteddata.value;
        this.totalProblemcount= this.apiRequsteddata.totalProblemcount;
    let payload:any ={
         "valid":this.apiRequsteddata.valid,
         "customer": this.apiRequsteddata.customer,
         "problemType": this.apiRequsteddata.problemType,
         "minThreshHold": this.apiRequsteddata.minThreshHold,
         'department':this.apiRequsteddata.department
       }
       return this.api.post(
         `${environment.backendDomain}ims/dashboard/ppm/departments/incidents`,
         payload
       ) .subscribe(
         res => {
          this.problemData =res.problems;
          this.incidentData = res.incidents
    //        this.incidentData = a.map(item => {
    //             const obj = {};
    //             obj['totalcount'] = item.incident_count.buckets;
    //             obj['key'] = item.key;
            
    //             return obj;
    //         })
    //    console.log(this.incidentData)
    
    })
}
onCellClicked(event) {
    if (event.colDef.headerName === 'Problem Id') {
      //this.openDialog(event.data, true);
      const dialogRef = this.dialog.open(EditComponent, {
        width: '800px',
        height: '400px',
        hasBackdrop: true,
        data: {
          serviceData: event.data ? event.data : [],
        },
        disableClose: false
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          // this.inProgress = true;
          const interval = setInterval(() => { 
            this.gettableData(); 
            clearInterval(interval)
        },500);
        }
      });
    } else  {
      this.api
      .get(`${environment.backendDomain}ims/dashboard/ppm/problem/incidents?customer=${event.data.customer}&department=${this.apiRequsteddata.department}&problemId=${event.data.problem_id}`)
      .subscribe((res) => {
        let x= document.getElementsByClassName('sub-content');
        x[0].scrollBy(0,1000)
        this.incidentData = res.incidents;
      });
    } 
  }
}