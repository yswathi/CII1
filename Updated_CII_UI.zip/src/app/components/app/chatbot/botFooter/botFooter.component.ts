import { Component , Output, EventEmitter} from '@angular/core';
import { Message } from '../../../../models';
import { MessageService } from '../../../../services/message.service';
import { SocketService } from '../../../../services/socket.service';
import { AuthenticationService } from '../../../../services/authentication.service';
import { environment } from '../../../../../environments/environment';
import { ProxyService } from '../../../../services/proxy.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bot-botFooter',
  templateUrl: './botFooter.component.html',
  styleUrls: ['./botFooter.component.scss']
})
export class BotFooterComponent {
  public message = new Message();
  public isSpeaking: boolean;
  private speechData: string;
  @Output() customers:any = new EventEmitter();
  private totalCustomers: any;
  constructor(
    private _socketService: SocketService,
    private _authenticationService: AuthenticationService,
    private _messageService: MessageService,
    private router: Router,
    private api : ProxyService
  ) {
    this.isSpeaking = false;
    this.message.text = '';
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 1) {
        this.totalCustomers = res.join(',');
      } else {
        this.totalCustomers = res[0];
      }
      this.customers.emit(this.totalCustomers);
    }, error => {
    });
  }
  public send() {
    if (this.message.text) {
      this.message.type = 'text';    
      this.message.from = this.totalCustomers;

      if (this._authenticationService.authenticationThroughChatbot) {
        this.message.id = '';
        this._authenticationService.authenticationThroughChatbot = false;
        this._authenticationService.idToken = this.message.text;
        this.router.navigateByUrl('/home');
        this._socketService.emitNAdd(this.message, 'otp');
      } else {
        this._socketService.emitNAdd(this.message, 'message');
      }
      this.message = new Message();
    }
  }
  public askFeedback() {
    this.message.from = 'bot';
    this.message.type = 'request-feedback';
    this._messageService.addMessage(this.message);
    this.message = new Message();
  }
}
