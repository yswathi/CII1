import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { BotFooterComponent } from './botFooter.component';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Message } from '../../../../models';
import { MessageService } from '../../../../services/message.service';
import { SocketService } from '../../../../services/socket.service';
import { UserService } from '../../../../services/user.service';
import { AuthenticationService } from '../../../../services/authentication.service';
import { Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule } from '@angular/forms';
describe('BotFooterComponent', () => {
  let fixture: ComponentFixture<BotFooterComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [BotFooterComponent],
      imports: [
        HttpClientTestingModule,
        ReactiveFormsModule,
        FormsModule,
        RouterTestingModule
      ],
      providers: [
        { provide: SocketService, useClass: SocketService },
        { provide: UserService, useClass: UserService },
        { provide: AuthenticationService, useClass: AuthenticationService },
        { provide: MessageService, useClass: MessageService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(BotFooterComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have ngOnDestroy', async(() => {
    expect(app.ngOnDestroy).toBeUndefined();
  }));
  it('should ask feedback ', async(() => {
    expect(app.askFeedback).toBeDefined();
    app.askFeedback();
  }));
  it(' should  have send() ', async(() => {
    expect(app.send).toBeDefined();
    app.message = {
      text: 'hari',
      type: 'text',
      from: 'where',
      id: '123'
    };
    app._authenticationService = {
      authenticationThroughChatbot: true
    };
    app.send();
  }));
  it(' should  have send() ', async(() => {
    expect(app.send).toBeDefined();
    app.message = {
      text: 'hari',
      type: 'text',
      from: 'where',
      id: '123'
    };
    app._authenticationService = {
      authenticationThroughChatbot: false
    };
    app.send();
  }));
  it(' should  have send() ', async(() => {
    expect(app.send).toBeDefined();
    app.message = {
      text: false,
      type: 'text',
      from: 'where',
      id: '123'
    };
    app.send();
  }));
});
