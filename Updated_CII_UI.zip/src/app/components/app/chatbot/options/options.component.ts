import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-options',
  templateUrl: './options.component.html',
  styleUrls: ['./options.component.scss']
})
export class OptionsComponent {
  @Input() msgInputs;

  @Output() selected = new EventEmitter<boolean>();

  constructor() {}

  onSelect(option) {
    this.selected.emit(option);
  }
}
