import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { OptionsComponent } from './options.component';
import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
describe('OptionsComponent', () => {
  let fixture: ComponentFixture<OptionsComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OptionsComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(OptionsComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have onSelect', async(() => {
    expect(app.onSelect).toBeDefined();
    app.onSelect();
  }));
});
