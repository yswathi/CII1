import { Component, OnInit } from '@angular/core';
import { FeedbackComponent } from './feedback.component';
import { Message } from '../../../../models';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import {
  SocketService,
  AuthenticationService,
  UserService,
  MessageService
} from '../../../../services';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
describe('FeedbackComponent', () => {
  let fixture: ComponentFixture<FeedbackComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [FeedbackComponent],
      imports: [HttpClientTestingModule],
      providers: [
        { provide: SocketService, useClass: SocketService },
        { provide: UserService, useClass: UserService },
        { provide: AuthenticationService, useClass: AuthenticationService },
        { provide: MessageService, useClass: MessageService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(FeedbackComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have rating', async(() => {
    var ratings = ['Terrible', 'Bad', 'Okay', 'Good', 'Great'];
    expect(app.onSelect).toBeDefined();
    app.onSelect(ratings);
  }));
});
