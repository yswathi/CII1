import { Component } from '@angular/core';
import { Message } from '../../../../models';
import { SocketService, AuthenticationService } from '../../../../services';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent {
  private message = new Message();

  ratings = ['Terrible', 'Bad', 'Okay', 'Good', 'Great'];
  selectedRating;
  constructor(
    private _socketService: SocketService,
    private _authenticationService: AuthenticationService
  ) {}

  onSelect(rating) {
    this.selectedRating = rating;
    this.message.id = '';
    this.message.from = 'user';
    this.message.type = 'text';
    this.message.text = this.ratings[rating];
    this.message.idToken = null;
    this._socketService.emitNAdd(this.message, 'feedback');
  }
}
