import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { OptionComponent } from './option.component';
import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
describe('OptionComponent', () => {
  let fixture: ComponentFixture<OptionComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OptionComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(OptionComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have onselect', async(() => {
    expect(app.onSelect).toBeDefined();
    app.onSelect();
  }));
});
