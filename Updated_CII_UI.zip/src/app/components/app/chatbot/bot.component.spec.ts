import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { BotComponent } from './bot.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
describe(' BotComponent', () => {
  let fixture: ComponentFixture<BotComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BotComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
    fixture = TestBed.createComponent(BotComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have setMinimizer', async(() => {
    expect(app.setMinimizer).toBeDefined();
    app.setMinimizer();
  }));
  it('should have reSize', async(() => {
    expect(app.reSize).toBeDefined();
    app.reSize();
  }));
});
