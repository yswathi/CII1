import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { QuestionsComponent } from './questions.component';
import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
describe('QuestionsComponent', () => {
  let fixture: ComponentFixture<QuestionsComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [QuestionsComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(QuestionsComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have onSelect', async(() => {
    expect(app.onSelect).toBeDefined();
    app.onSelect();
  }));
});
