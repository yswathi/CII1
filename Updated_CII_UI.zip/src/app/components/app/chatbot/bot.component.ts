import { Component, ElementRef } from '@angular/core';

@Component({
  selector: 'app-bot',
  templateUrl: './bot.component.html',
  styleUrls: ['./bot.component.scss']
})
export class BotComponent {
  minimizer = true;
  toggleSize = false;
  constructor() { }

  setMinimizer(isMinimize) {
    this.minimizer = isMinimize;
  }

  reSize(event) {
    this.toggleSize = event;
  }
}