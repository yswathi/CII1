import { Component, OnInit, ElementRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import { environment } from '../../../../../environments/environment';

import {
  SocketService,
  MessageService,
  AuthenticationService,
  ProxyService
} from '../../../../services';
import { Message, IMessage, User } from '../../../../models';

@Component({
  selector: 'app-bot-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.scss']
})
export class BodyComponent implements OnInit {
  public messages: Observable<Message[]>;
  public botIsTyping = false;
  public totalCustomers : string;
  constructor(
    private _socketService: SocketService,
    private _messageService: MessageService,
    private _authenticationService: AuthenticationService,
    private _elRef: ElementRef,
    private api : ProxyService
  ) {
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 1) {
        this.totalCustomers = res.join(',');
      } else {
        this.totalCustomers = res[0];
      }
    }, error => {
    });
  }
  
  ngOnInit() {
    this._socketService.connect();
    this.messages = this._messageService.messages.do(() => {
      setTimeout(() => {
        this.scrollToBottom();
      });
    });
    this._messageService.newMessage.subscribe(msg => {
      msg.from === this.totalCustomers
        ? (this.botIsTyping = true)
        : (this.botIsTyping = false);
    });
  }

  scrollToBottom(): void {
    const scrollPane: any = this._elRef.nativeElement.querySelector('.msg-list')
      .parentElement;
    scrollPane.scrollTop = scrollPane.scrollHeight;
  }

  public selected(option) {
    let message;
    if (option.id === 0) {
      message = new Message({
        id: option.id,
        type: 'text',
        text: "Please enter the code you received or type 'quit' to end",
        sentAt: new Date(),
        from: 'bot',
        idToken: null
      });
      this._messageService.addMessage(message);
      this._authenticationService.authenticationThroughChatbot = true;
    } else {
      message = new Message({
        id: option.id,
        type: 'text',
        text: option.name,
        sentAt: new Date(),
        from: this.totalCustomers,
        idToken: null
      });
      this._socketService.emitNAdd(message, 'message');
    }
  }
}
