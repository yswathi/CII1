import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-bot-botHeader',
  templateUrl: './botHeader.component.html',
  styleUrls: ['./botHeader.component.scss']
})
export class BotHeaderComponent  {
  flagvalue:boolean=true;
  flagmin:boolean=false;
  @Output() minimizer = new EventEmitter<boolean>();
  @Output() setResize = new EventEmitter<boolean>();
  setMinimizer() {
    this.minimizer.emit();
  }
  toggleResize(flag) {
    if(flag==true)
    {
     this.flagvalue=!this.flagvalue;
     
    }
    else if(flag==false){
      this.flagvalue=!this.flagvalue;
    }
    this.setResize.emit(flag);
  }
}