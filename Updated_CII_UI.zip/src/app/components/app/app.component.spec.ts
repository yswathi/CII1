import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { Keepalive } from '@ng-idle/keepalive';
import { AuthenticationService } from '../../services/authentication.service';
import { SocketService } from '../../services/socket.service';
import { MessageService } from '../../services/message.service';
import { Message } from '../../models';
import { Idle, DEFAULT_INTERRUPTSOURCES, IdleExpiry } from '@ng-idle/core';
import { environment } from '../../../environments/environment';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { UserService } from '../../services/user.service';

describe(' AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [AppComponent],
      imports: [HttpClientTestingModule],
      providers: [
        { provide: Idle, useClass: Idle },
        { provide: IdleExpiry, useClass: IdleExpiry },
        { provide: Keepalive, useClass: Keepalive },
        { provide: SocketService, useClass: SocketService },
        { provide: UserService, useClass: UserService },
        { provide: AuthenticationService, useClass: AuthenticationService },
        { provide: MessageService, useClass: MessageService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.debugElement.componentInstance;
    console.log(app);
  }));
  it('should create the app', () => {
    expect(app).toBeDefined();
  });
  it('should define the varibales on load', () => {
    expect(app.idleState).toBeDefined();
    expect(app.idleState).toBe('Not started.');
    expect(app.timedOut).toBeDefined();
    expect(app.timedOut).toBeFalsy();
  });
  it('should define setupIdle', () => {
    expect(app.setUpIdleTimer).toBeDefined();
    expect(typeof app.setUpIdleTimer).toBe('function');
    app.setUpIdleTimer();
  });
  it('should have reset', () => {
    expect(app.reset).toBeDefined();
    expect(typeof app.reset).toBe('function');
    app.reset();
  });
});
