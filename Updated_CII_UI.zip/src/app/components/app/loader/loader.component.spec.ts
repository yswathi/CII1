import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { LoaderService } from './loader.service';
import { LoaderComponent } from './loader.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe('LoaderComponent', () => {
  let fixture: ComponentFixture<LoaderComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [LoaderComponent],
      imports: [HttpClientTestingModule],
      providers: [{ provide: LoaderService, useClass: LoaderService }]
    }).compileComponents();
    fixture = TestBed.createComponent(LoaderComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
  it('should  call ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
});
