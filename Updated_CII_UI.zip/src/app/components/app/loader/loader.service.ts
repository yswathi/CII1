import {Injectable} from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
@Injectable()
export class LoaderService {
    isLoading = new BehaviorSubject(false);
    public start(): void {
        this.isLoading.next(true);
    }
    public stop(): void {
        window.setTimeout(() => {
            this.isLoading.next(false);
        }, 0);
    }
}
