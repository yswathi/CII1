import { Component, OnInit } from '@angular/core';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { SocketService } from '../../services/socket.service';
import { Message } from '../../models';
import { AuthenticationService } from '../../services/authentication.service';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { ProxyService } from '../../services';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  message = new Message();
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  firstTimeIdleSetup = true;
  roles = [];
  resources = [];
  groups = [];
  userName: any;
  constructor(
    private idle: Idle,
    private keepalive: Keepalive,
    private _socketService: SocketService,
    private _authenticationService: AuthenticationService,
    private http: HttpClient,
    private api: ProxyService,
    private data: UserService,
  ) {
    _socketService.myLogging$.subscribe((newBool: boolean) => {
      if (newBool) {
        if (this.firstTimeIdleSetup) {
          this.firstTimeIdleSetup = false;
          this.setUpIdleTimer();
          this.reset();
        } else if (this.timedOut) {
          this.reset();
        }
      }
    });
  }

  ngOnInit(): void {
    this.api.get(environment.backendDomain + 'ims/user').subscribe((response) => {
      this.userName = response.displayName;
      if (response.roles.length > 0) {
        this.roles = response.roles;
      } else {
        this.roles = this.data.roles;
      }
      if (response.resources.length > 0) {
        this.resources = response.resources;
      } else {
        this.resources = this.data.resources;
      }
      if (response.groups.length > 0) {
        this.groups = response.groups;
      } else {
        this.groups = this.data.groups;
      }
    }, (error) => {
      console.log(error.error.text);
    });
  }
  setUpIdleTimer() {
    this.idle.setIdle(environment.botIdleTime);
    this.idle.setTimeout(environment.botTimeout);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleStart.subscribe(() => {
      this.idleState = "You've gone idle!";
    });

    this.idle.onTimeoutWarning.subscribe(countdown => {
      this.idleState = 'You will time out in ' + countdown + ' seconds!';
    });

    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.message.type = 'text';
      this.message.from = 'user';
      this.message.text = 'Timeout';
      this._authenticationService.idToken = '';
      this._socketService.emit(this.message, 'timeout');
      this.message = new Message();
    });

    this.idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle.';
    });
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Start';
    this.timedOut = false;
  }
}
