import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from './header.component';
import { ProxyService } from '../../../services/proxy.service';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
describe('HeaderComponent', () => {
  let fixture: ComponentFixture<HeaderComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      imports: [HttpClientTestingModule, RouterTestingModule, RouterModule],
      providers: [{ provide: ProxyService, useClass: ProxyService }]
    }).compileComponents();
    fixture = TestBed.createComponent(HeaderComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
  it('should have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should have updateInterval', async(() => {
    expect(app.updateInterval).toBeDefined();
    app.updateInterval();
  }));
  it('should have goPpm', async(() => {
    expect(app.goPpm).toBeDefined();
    app.goPpm();
  }));
  it('should have ngOnDestroy', async(() => {
    expect(app.ngOnDestroy).toBeDefined();
    app.ngOnDestroy();
  }));
});
