import { Component, OnInit } from '@angular/core';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import {  Router, ActivatedRoute} from '@angular/router';
import { KeycloakService } from '../../../../shared/keyCloak.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  notifications: any = [];
  modelInterval: any;
  intervalTime: number = 100;
  user: any = {};
  toolTipUserRole;
  defaultUrlPath;
  constructor(private api: ProxyService, private router: Router, private kcService: KeycloakService, private route: ActivatedRoute) {}
  ngOnInit() {
    this.updateInterval();
    this.api.get(environment.backendDomain + 'ims/user').subscribe((response) => {
      this.user.email = response.email;
      this.user.firstName = response.firstName;
      this.user.lastName = response.lastName;
      this.user.displayName = response.displayName;
      this.user.roles = response.roles;
      this.user.resources = response.resources.sort();
      this.toolTipUserRole = response.roles ? response.roles.toString() : '';

      // const defaultTab = this.user.resources[0];
      // let filteredRoutes = this.router.config.filter((data)=>{ return data.hasOwnProperty('children') && data.path == 'dashboard'});
      // let dashboardRoutes = filteredRoutes[0].children;
      // const defaultRoute = dashboardRoutes.filter((dataObj)=>{ 
      //   return dataObj.data && dataObj.data.rowMapper && dataObj.data.rowMapper === defaultTab;
      // });
    });
  }
  redirectToDefaultTab(){
    // if(this.user.resources.indexOf('TAB1') ! == -1){
    //   this.router.navigateByUrl('/dashboard/value');
    // }else {
    //   this.router.navigateByUrl('/dashboard/knowledge');
    // }
    
    this.router.navigateByUrl('/dashboard/about');
  }
  


  updateInterval() {
    /*this.modelInterval = setTimeout(() => {
      this.api.get(`${environment.backendDomain}ims/ppm/notifications`).subscribe(res => {
        this.notifications = res.response;
      });
      this.intervalTime = 60000;
      this.updateInterval();
    }, this.intervalTime);*/

  }

  goPpm() {
    this.api.get(`${environment.backendDomain}ims/ppm/updatePpm`).subscribe(res => {
      this.router.navigateByUrl(`/dashboard/notifications`);
    }, err => {
       //todo for any error
      this.router.navigateByUrl(`/dashboard/notifications`);
    });
  }

logout() {
 //this.kcService.logout();
  // this.api.get(`${environment.backendDomain}ims/saml/logout`).subscribe(res => {
  // })
  this.api.get(`${environment.backendDomain}ims/app/auth/logout`).subscribe(res => {
    console.log(res)
  })
  
}

logout1(){
  this.api.get(`${environment.backendDomain}ims/app/request/logout`).subscribe(res => {
    console.log(res);
  })
  
}
  ngOnDestroy() {
    clearTimeout(this.modelInterval);
  }
}
