import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Message } from '../../../models';
import { SocketService } from '../../../services/socket.service';
import { AuthenticationService } from '../../../services/authentication.service';

@Component({
  selector: 'app-signin',
  templateUrl: 'signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  private message = new Message();
  model: any = {};
  loading = false;
  returnUrl: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private _socketService: SocketService,
    private _authenticationService: AuthenticationService
  ) {}

  ngOnInit() {
    // reset login status
    this._authenticationService.logout();
    this.returnUrl = '/signin-response';
    this.message.text = '';
  }

  login() {
    this._authenticationService
      .login(this.model.username, this.model.password)
      .then(otp => {
        if (this._authenticationService.authenticationThroughChatbot) {
          this.router.navigate([this.returnUrl, otp]);
        } else {
          this.message.text = otp;
          this.message.type = 'text';
          this.message.from = 'user';
          this.message.id = '';
          this._socketService.emit(this.message, 'otp');
          this.message = new Message();
          this.router.navigateByUrl('/home');
        }
      });
  }
}
