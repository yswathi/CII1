import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { AuthenticationService } from '../../../services/authentication.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SigninResponseComponent } from './signinResponse.component';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe(' SigninResponseComponent', () => {
  let fixture: ComponentFixture<SigninResponseComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [SigninResponseComponent],
      imports: [HttpClientTestingModule, RouterTestingModule, FormsModule],
      providers: [
        { provide: AuthenticationService, useClass: AuthenticationService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(SigninResponseComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));

  it('should have ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
});
