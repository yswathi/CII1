import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { AuthenticationService } from '../../../services/authentication.service';

@Component({
  templateUrl: 'trendForecast.component.html',
  styleUrls: ['./trendForecast.component.scss']
})
export class TrendForecastComponent implements OnInit, OnDestroy {
  otp: any;
  private sub: any;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.otp = +params['otp'];
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
