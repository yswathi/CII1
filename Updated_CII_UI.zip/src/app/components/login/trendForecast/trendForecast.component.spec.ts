import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { AuthenticationService } from '../../../services/authentication.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TrendForecastComponent } from './trendForecast.component';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe(' TrendForecastComponent', () => {
  let fixture: ComponentFixture<TrendForecastComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [TrendForecastComponent],
      imports: [HttpClientTestingModule, RouterTestingModule, FormsModule],
      providers: [
        { provide: AuthenticationService, useClass: AuthenticationService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(TrendForecastComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));

  it('should have ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));

  it('should have ngOnDestroy', async(() => {
    expect(app.ngOnDestroy).toBeDefined();
    app.ngOnDestroy();
  }));
});
