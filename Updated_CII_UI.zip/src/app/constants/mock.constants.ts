export const MOCK = {
  OPTIONS: [
    { id: 1, name: 'Incident Creation' },
    { id: 2, name: 'Incident Enquiry' },
    { id: 3, name: 'Information' }
  ]
};
