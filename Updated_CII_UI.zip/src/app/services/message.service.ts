import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import 'rxjs/add/operator/scan';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/publishReplay';

import { Message } from '../models';

@Injectable()
export class MessageService {
  public messages: Observable<Message[]>;
  public newMessage = new Subject<Message>();
  public create = new Subject<Message>();
  private initialMessages = [];

  constructor(private _authenticationService: AuthenticationService) {
    this.messages = this.create
      .scan((messages: Message[], message: Message) => {
        return messages.concat(message);
      }, this.initialMessages)
      .publishReplay(1)
      .refCount();

    this.newMessage
      .subscribe(this.create);
  }

  public addMessage(message: Message) {
    message.idToken = this._authenticationService.idToken;
    this.newMessage.next(message);
  }

}
