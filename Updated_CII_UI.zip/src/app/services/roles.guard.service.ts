import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRoute, Event, NavigationEnd } from '@angular/router';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { ProxyService } from '../services/proxy.service';
import { UserService } from '../services/user.service';

@Injectable()
export class RolesGuard implements CanActivate {

    constructor(private router: Router, private http: HttpClient, private api: ProxyService, private route: ActivatedRoute, private data: UserService) { }
    canActivate() {
        return this.api.get(environment.backendDomain + 'ims/user').map(response => {
            const res = response;
            if (res && res.resources.length > 0) {
                res.resources = res.resources;
            } else {
                res.resources = this.data.resources;
            }
            const defaultTab = res.resources.sort()[0];
            if (this.router.url == '/' && defaultTab === 'TAB2') {
                this.router.navigateByUrl('/dashboard/value');
                return false;
            }
            return true;

        });
    }

}