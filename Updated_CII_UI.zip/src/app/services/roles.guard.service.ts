import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRoute,Event,NavigationEnd } from '@angular/router';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { ProxyService } from '../services/proxy.service';

@Injectable()
export class RolesGuard implements CanActivate {

    constructor(private router: Router, private http: HttpClient, private api: ProxyService, private route: ActivatedRoute) {}
    canActivate() {
        return this.api.get(environment.backendDomain + 'ims/user').map(response => {
            const res = response;
            const defaultTab = res.resources.sort()[0];
            if(this.router.url == '/' && defaultTab === 'TAB2') {
                this.router.navigateByUrl('/dashboard/value');
                return false;
            } 
            return true;
            
        });
    }
    
}