import { Injectable, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { User } from '../models';

@Injectable()
export class UserService {
  groups = ["OldWorldIndustries",
    "NDCP",
    "Airgas",
    "Kimco",
    "Boehringer_Ingelheim",
    "Kaiser",
    "MagicLeap",
    "DMF",
    "Glazers",
    "RNDC",
    "Puma",
    "OLIN",
    "CityOfDallas",
    "Aflac",
    "Caterpillar",
    "Bissell",
    "Illinois",
    "DAS",
    "FloridaCollegeSystem",
    "Carpenter",
    "TMT_Project"];
  resources = [
    "TAB1",
    "TAB2",
    "TAB3",
    "TAB4",
    "TAB5"];
  roles = ["ADMIN"];
  currentUser = new BehaviorSubject<User>(null);
  ppmdata;
  dept;
  private customer = new BehaviorSubject(null);

  public setCurrentUser(newUser: User): void {
    this.currentUser.next(newUser);
  }

  public setSelectedCustomer(cust) {
    this.customer.next(cust);
  }
  public getSelectedCustomer() {
    return this.customer.asObservable();
  }
  public setDetaildatappm(data) {
    this.ppmdata = data;
    var a = JSON.stringify(data)
    localStorage.setItem("data", a)
  }
  public getDetaildatappm() {
    var x = localStorage.getItem("data");
    console.log(JSON.parse(x))
    return this.ppmdata
  }
  public setDepartment(dept) {
    this.dept = dept;
    console.log(this.dept)
  }
  public getDepartment() {
    return this.dept;
  }

  public getRoles() {
    return this.roles;
  }

  public getGroups() {
    return this.groups;
  }

  public getResources() {
    return this.resources;
  }

}
