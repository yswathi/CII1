import { Injectable, Output , EventEmitter} from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { User } from '../models';

@Injectable()
export class UserService {
  currentUser = new BehaviorSubject<User>(null);
  ppmdata;
  dept;
  private customer = new BehaviorSubject(null);

  public setCurrentUser(newUser: User): void {
    this.currentUser.next(newUser);
  }

  public setSelectedCustomer(cust){
    this.customer.next(cust);
  }
  public getSelectedCustomer(){
    return this.customer.asObservable();
  }
  public setDetaildatappm(data){
    this.ppmdata= data;
    var a= JSON.stringify(data)
    localStorage.setItem("data",a)
  }
  public getDetaildatappm(){
    var x=localStorage.getItem("data");
    console.log(JSON.parse(x))   
    return this.ppmdata
  }
  public setDepartment(dept){
    this.dept= dept;
    console.log(this.dept)
  }
  public getDepartment(){
    return this.dept;
  }

}
